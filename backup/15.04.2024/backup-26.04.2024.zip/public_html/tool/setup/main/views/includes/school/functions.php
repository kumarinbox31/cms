<?php
add_action('ab_head', 'registerBeforeHeadContent');
add_action('ab_footer', 'registerAfterFooterContent');
add_action('ab_body_class', 'registerBodyClass');

function registerBeforeHeadContent(){
    ob_start();
    ?>
    <meta name='robots' content='max-image-preview:large' />
    <script>
        window._wpemojiSettings = { "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/", "ext": ".png", "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/", "svgExt": ".svg", "source": { "concatemoji": "https:\/\/taekwondounion.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.5" } };
        /*! This file is auto-generated */
        !function (i, n) { var o, s, e; function c(e) { try { var t = { supportTests: e, timestamp: (new Date).valueOf() }; sessionStorage.setItem(o, JSON.stringify(t)) } catch (e) { } } function p(e, t, n) { e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(t, 0, 0); var t = new Uint32Array(e.getImageData(0, 0, e.canvas.width, e.canvas.height).data), r = (e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(n, 0, 0), new Uint32Array(e.getImageData(0, 0, e.canvas.width, e.canvas.height).data)); return t.every(function (e, t) { return e === r[t] }) } function u(e, t, n) { switch (t) { case "flag": return n(e, "\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f", "\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f") ? !1 : !n(e, "\ud83c\uddfa\ud83c\uddf3", "\ud83c\uddfa\u200b\ud83c\uddf3") && !n(e, "\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f", "\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f"); case "emoji": return !n(e, "\ud83d\udc26\u200d\u2b1b", "\ud83d\udc26\u200b\u2b1b") }return !1 } function f(e, t, n) { var r = "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope ? new OffscreenCanvas(300, 150) : i.createElement("canvas"), a = r.getContext("2d", { willReadFrequently: !0 }), o = (a.textBaseline = "top", a.font = "600 32px Arial", {}); return e.forEach(function (e) { o[e] = t(a, e, n) }), o } function t(e) { var t = i.createElement("script"); t.src = e, t.defer = !0, i.head.appendChild(t) } "undefined" != typeof Promise && (o = "wpEmojiSettingsSupports", s = ["flag", "emoji"], n.supports = { everything: !0, everythingExceptFlag: !0 }, e = new Promise(function (e) { i.addEventListener("DOMContentLoaded", e, { once: !0 }) }), new Promise(function (t) { var n = function () { try { var e = JSON.parse(sessionStorage.getItem(o)); if ("object" == typeof e && "number" == typeof e.timestamp && (new Date).valueOf() < e.timestamp + 604800 && "object" == typeof e.supportTests) return e.supportTests } catch (e) { } return null }(); if (!n) { if ("undefined" != typeof Worker && "undefined" != typeof OffscreenCanvas && "undefined" != typeof URL && URL.createObjectURL && "undefined" != typeof Blob) try { var e = "postMessage(" + f.toString() + "(" + [JSON.stringify(s), u.toString(), p.toString()].join(",") + "));", r = new Blob([e], { type: "text/javascript" }), a = new Worker(URL.createObjectURL(r), { name: "wpTestEmojiSupports" }); return void (a.onmessage = function (e) { c(n = e.data), a.terminate(), t(n) }) } catch (e) { } c(n = f(s, u, p)) } t(n) }).then(function (e) { for (var t in e) n.supports[t] = e[t], n.supports.everything = n.supports.everything && n.supports[t], "flag" !== t && (n.supports.everythingExceptFlag = n.supports.everythingExceptFlag && n.supports[t]); n.supports.everythingExceptFlag = n.supports.everythingExceptFlag && !n.supports.flag, n.DOMReady = !1, n.readyCallback = function () { n.DOMReady = !0 } }).then(function () { return e }).then(function () { var e; n.supports.everything || (n.readyCallback(), (e = n.source || {}).concatemoji ? t(e.concatemoji) : e.wpemoji && e.twemoji && (t(e.twemoji), t(e.wpemoji))) })) }((window, document), window._wpemojiSettings);
    </script>
    <link rel='stylesheet' id='ht_ctc_main_css-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/click-to-chat-for-whatsapp/new/inc/assets/css/main862f.css?ver=3.30.1' media='all' />
    <style id='wp-emoji-styles-inline-css'>
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 0.07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel='stylesheet' id='wp-block-library-css' href='<?php echo theme_path(); ?>wp-includes/css/dist/block-library/style.min8f99.css?ver=6.5'
        media='all' />
    <style id='classic-theme-styles-inline-css'>
        /*! This file is auto-generated */
        .wp-block-button__link {
            color: #fff;
            background-color: #32373c;
            border-radius: 9999px;
            box-shadow: none;
            text-decoration: none;
            padding: calc(.667em + 2px) calc(1.333em + 2px);
            font-size: 1.125em
        }

        .wp-block-file__button {
            background: #32373c;
            color: #fff;
            text-decoration: none
        }
    </style>
    <style id='global-styles-inline-css'>
        body {
            --wp--preset--color--black: #000000;
            --wp--preset--color--cyan-bluish-gray: #abb8c3;
            --wp--preset--color--white: #ffffff;
            --wp--preset--color--pale-pink: #f78da7;
            --wp--preset--color--vivid-red: #cf2e2e;
            --wp--preset--color--luminous-vivid-orange: #ff6900;
            --wp--preset--color--luminous-vivid-amber: #fcb900;
            --wp--preset--color--light-green-cyan: #7bdcb5;
            --wp--preset--color--vivid-green-cyan: #00d084;
            --wp--preset--color--pale-cyan-blue: #8ed1fc;
            --wp--preset--color--vivid-cyan-blue: #0693e3;
            --wp--preset--color--vivid-purple: #9b51e0;
            --wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);
            --wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
            --wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);
            --wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);
            --wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
            --wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
            --wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
            --wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
            --wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
            --wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
            --wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
            --wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
            --wp--preset--font-size--small: 13px;
            --wp--preset--font-size--medium: 20px;
            --wp--preset--font-size--large: 36px;
            --wp--preset--font-size--x-large: 42px;
            --wp--preset--spacing--20: 0.44rem;
            --wp--preset--spacing--30: 0.67rem;
            --wp--preset--spacing--40: 1rem;
            --wp--preset--spacing--50: 1.5rem;
            --wp--preset--spacing--60: 2.25rem;
            --wp--preset--spacing--70: 3.38rem;
            --wp--preset--spacing--80: 5.06rem;
            --wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);
            --wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);
            --wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);
        }

        :where(.is-layout-flex) {
            gap: 0.5em;
        }

        :where(.is-layout-grid) {
            gap: 0.5em;
        }

        body .is-layout-flow>.alignleft {
            float: left;
            margin-inline-start: 0;
            margin-inline-end: 2em;
        }

        body .is-layout-flow>.alignright {
            float: right;
            margin-inline-start: 2em;
            margin-inline-end: 0;
        }

        body .is-layout-flow>.aligncenter {
            margin-left: auto !important;
            margin-right: auto !important;
        }

        body .is-layout-constrained>.alignleft {
            float: left;
            margin-inline-start: 0;
            margin-inline-end: 2em;
        }

        body .is-layout-constrained>.alignright {
            float: right;
            margin-inline-start: 2em;
            margin-inline-end: 0;
        }

        body .is-layout-constrained>.aligncenter {
            margin-left: auto !important;
            margin-right: auto !important;
        }

        body .is-layout-constrained> :where(:not(.alignleft):not(.alignright):not(.alignfull)) {
            max-width: var(--wp--style--global--content-size);
            margin-left: auto !important;
            margin-right: auto !important;
        }

        body .is-layout-constrained>.alignwide {
            max-width: var(--wp--style--global--wide-size);
        }

        body .is-layout-flex {
            display: flex;
        }

        body .is-layout-flex {
            flex-wrap: wrap;
            align-items: center;
        }

        body .is-layout-flex>* {
            margin: 0;
        }

        body .is-layout-grid {
            display: grid;
        }

        body .is-layout-grid>* {
            margin: 0;
        }

        :where(.wp-block-columns.is-layout-flex) {
            gap: 2em;
        }

        :where(.wp-block-columns.is-layout-grid) {
            gap: 2em;
        }

        :where(.wp-block-post-template.is-layout-flex) {
            gap: 1.25em;
        }

        :where(.wp-block-post-template.is-layout-grid) {
            gap: 1.25em;
        }

        .has-black-color {
            color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-color {
            color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-color {
            color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-color {
            color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-color {
            color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-color {
            color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-color {
            color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-color {
            color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-color {
            color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-color {
            color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-color {
            color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-color {
            color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-black-background-color {
            background-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-background-color {
            background-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-background-color {
            background-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-background-color {
            background-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-background-color {
            background-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-background-color {
            background-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-background-color {
            background-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-background-color {
            background-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-background-color {
            background-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-background-color {
            background-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-black-border-color {
            border-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-border-color {
            border-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-border-color {
            border-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-border-color {
            border-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-border-color {
            border-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-border-color {
            border-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-border-color {
            border-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-border-color {
            border-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-border-color {
            border-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-border-color {
            border-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-vivid-cyan-blue-to-vivid-purple-gradient-background {
            background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;
        }

        .has-light-green-cyan-to-vivid-green-cyan-gradient-background {
            background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;
        }

        .has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-orange-to-vivid-red-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;
        }

        .has-very-light-gray-to-cyan-bluish-gray-gradient-background {
            background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;
        }

        .has-cool-to-warm-spectrum-gradient-background {
            background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;
        }

        .has-blush-light-purple-gradient-background {
            background: var(--wp--preset--gradient--blush-light-purple) !important;
        }

        .has-blush-bordeaux-gradient-background {
            background: var(--wp--preset--gradient--blush-bordeaux) !important;
        }

        .has-luminous-dusk-gradient-background {
            background: var(--wp--preset--gradient--luminous-dusk) !important;
        }

        .has-pale-ocean-gradient-background {
            background: var(--wp--preset--gradient--pale-ocean) !important;
        }

        .has-electric-grass-gradient-background {
            background: var(--wp--preset--gradient--electric-grass) !important;
        }

        .has-midnight-gradient-background {
            background: var(--wp--preset--gradient--midnight) !important;
        }

        .has-small-font-size {
            font-size: var(--wp--preset--font-size--small) !important;
        }

        .has-medium-font-size {
            font-size: var(--wp--preset--font-size--medium) !important;
        }

        .has-large-font-size {
            font-size: var(--wp--preset--font-size--large) !important;
        }

        .has-x-large-font-size {
            font-size: var(--wp--preset--font-size--x-large) !important;
        }

        .wp-block-navigation a:where(:not(.wp-element-button)) {
            color: inherit;
        }

        :where(.wp-block-post-template.is-layout-flex) {
            gap: 1.25em;
        }

        :where(.wp-block-post-template.is-layout-grid) {
            gap: 1.25em;
        }

        :where(.wp-block-columns.is-layout-flex) {
            gap: 2em;
        }

        :where(.wp-block-columns.is-layout-grid) {
            gap: 2em;
        }

        .wp-block-pullquote {
            font-size: 1.5em;
            line-height: 1.6;
        }
    </style>
    <link rel='stylesheet' id='hfe-style-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/header-footer-elementor/assets/css/header-footer-elementor10ef.css?ver=1.6.17'
        media='all' />
    <link rel='stylesheet' id='hello-elementor-theme-style-css'
        href='<?php echo theme_path(); ?>wp-content/themes/hello-elementor/theme.minc141.css?ver=2.6.1' media='all' />
    <link rel='stylesheet' id='elementor-frontend-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/css/frontend-lite.minf92b.css?ver=3.16.6' media='all' />
    <style id='elementor-frontend-inline-css'>
        @-webkit-keyframes ha_fadeIn {
            0% {
                opacity: 0
            }

            to {
                opacity: 1
            }
        }

        @keyframes ha_fadeIn {
            0% {
                opacity: 0
            }

            to {
                opacity: 1
            }
        }

        @-webkit-keyframes ha_zoomIn {
            0% {
                opacity: 0;
                -webkit-transform: scale3d(.3, .3, .3);
                transform: scale3d(.3, .3, .3)
            }

            50% {
                opacity: 1
            }
        }

        @keyframes ha_zoomIn {
            0% {
                opacity: 0;
                -webkit-transform: scale3d(.3, .3, .3);
                transform: scale3d(.3, .3, .3)
            }

            50% {
                opacity: 1
            }
        }

        @-webkit-keyframes ha_rollIn {
            0% {
                opacity: 0;
                -webkit-transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);
                transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg)
            }

            to {
                opacity: 1
            }
        }

        @keyframes ha_rollIn {
            0% {
                opacity: 0;
                -webkit-transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);
                transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg)
            }

            to {
                opacity: 1
            }
        }

        @-webkit-keyframes ha_bounce {

            0%,
            20%,
            53%,
            to {
                -webkit-animation-timing-function: cubic-bezier(.215, .61, .355, 1);
                animation-timing-function: cubic-bezier(.215, .61, .355, 1)
            }

            40%,
            43% {
                -webkit-transform: translate3d(0, -30px, 0) scaleY(1.1);
                transform: translate3d(0, -30px, 0) scaleY(1.1);
                -webkit-animation-timing-function: cubic-bezier(.755, .05, .855, .06);
                animation-timing-function: cubic-bezier(.755, .05, .855, .06)
            }

            70% {
                -webkit-transform: translate3d(0, -15px, 0) scaleY(1.05);
                transform: translate3d(0, -15px, 0) scaleY(1.05);
                -webkit-animation-timing-function: cubic-bezier(.755, .05, .855, .06);
                animation-timing-function: cubic-bezier(.755, .05, .855, .06)
            }

            80% {
                -webkit-transition-timing-function: cubic-bezier(.215, .61, .355, 1);
                transition-timing-function: cubic-bezier(.215, .61, .355, 1);
                -webkit-transform: translate3d(0, 0, 0) scaleY(.95);
                transform: translate3d(0, 0, 0) scaleY(.95)
            }

            90% {
                -webkit-transform: translate3d(0, -4px, 0) scaleY(1.02);
                transform: translate3d(0, -4px, 0) scaleY(1.02)
            }
        }

        @keyframes ha_bounce {

            0%,
            20%,
            53%,
            to {
                -webkit-animation-timing-function: cubic-bezier(.215, .61, .355, 1);
                animation-timing-function: cubic-bezier(.215, .61, .355, 1)
            }

            40%,
            43% {
                -webkit-transform: translate3d(0, -30px, 0) scaleY(1.1);
                transform: translate3d(0, -30px, 0) scaleY(1.1);
                -webkit-animation-timing-function: cubic-bezier(.755, .05, .855, .06);
                animation-timing-function: cubic-bezier(.755, .05, .855, .06)
            }

            70% {
                -webkit-transform: translate3d(0, -15px, 0) scaleY(1.05);
                transform: translate3d(0, -15px, 0) scaleY(1.05);
                -webkit-animation-timing-function: cubic-bezier(.755, .05, .855, .06);
                animation-timing-function: cubic-bezier(.755, .05, .855, .06)
            }

            80% {
                -webkit-transition-timing-function: cubic-bezier(.215, .61, .355, 1);
                transition-timing-function: cubic-bezier(.215, .61, .355, 1);
                -webkit-transform: translate3d(0, 0, 0) scaleY(.95);
                transform: translate3d(0, 0, 0) scaleY(.95)
            }

            90% {
                -webkit-transform: translate3d(0, -4px, 0) scaleY(1.02);
                transform: translate3d(0, -4px, 0) scaleY(1.02)
            }
        }

        @-webkit-keyframes ha_bounceIn {

            0%,
            20%,
            40%,
            60%,
            80%,
            to {
                -webkit-animation-timing-function: cubic-bezier(.215, .61, .355, 1);
                animation-timing-function: cubic-bezier(.215, .61, .355, 1)
            }

            0% {
                opacity: 0;
                -webkit-transform: scale3d(.3, .3, .3);
                transform: scale3d(.3, .3, .3)
            }

            20% {
                -webkit-transform: scale3d(1.1, 1.1, 1.1);
                transform: scale3d(1.1, 1.1, 1.1)
            }

            40% {
                -webkit-transform: scale3d(.9, .9, .9);
                transform: scale3d(.9, .9, .9)
            }

            60% {
                opacity: 1;
                -webkit-transform: scale3d(1.03, 1.03, 1.03);
                transform: scale3d(1.03, 1.03, 1.03)
            }

            80% {
                -webkit-transform: scale3d(.97, .97, .97);
                transform: scale3d(.97, .97, .97)
            }

            to {
                opacity: 1
            }
        }

        @keyframes ha_bounceIn {

            0%,
            20%,
            40%,
            60%,
            80%,
            to {
                -webkit-animation-timing-function: cubic-bezier(.215, .61, .355, 1);
                animation-timing-function: cubic-bezier(.215, .61, .355, 1)
            }

            0% {
                opacity: 0;
                -webkit-transform: scale3d(.3, .3, .3);
                transform: scale3d(.3, .3, .3)
            }

            20% {
                -webkit-transform: scale3d(1.1, 1.1, 1.1);
                transform: scale3d(1.1, 1.1, 1.1)
            }

            40% {
                -webkit-transform: scale3d(.9, .9, .9);
                transform: scale3d(.9, .9, .9)
            }

            60% {
                opacity: 1;
                -webkit-transform: scale3d(1.03, 1.03, 1.03);
                transform: scale3d(1.03, 1.03, 1.03)
            }

            80% {
                -webkit-transform: scale3d(.97, .97, .97);
                transform: scale3d(.97, .97, .97)
            }

            to {
                opacity: 1
            }
        }

        @-webkit-keyframes ha_flipInX {
            0% {
                opacity: 0;
                -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
                transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
                -webkit-animation-timing-function: ease-in;
                animation-timing-function: ease-in
            }

            40% {
                -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
                transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
                -webkit-animation-timing-function: ease-in;
                animation-timing-function: ease-in
            }

            60% {
                opacity: 1;
                -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
                transform: perspective(400px) rotate3d(1, 0, 0, 10deg)
            }

            80% {
                -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
                transform: perspective(400px) rotate3d(1, 0, 0, -5deg)
            }
        }

        @keyframes ha_flipInX {
            0% {
                opacity: 0;
                -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
                transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
                -webkit-animation-timing-function: ease-in;
                animation-timing-function: ease-in
            }

            40% {
                -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
                transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
                -webkit-animation-timing-function: ease-in;
                animation-timing-function: ease-in
            }

            60% {
                opacity: 1;
                -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
                transform: perspective(400px) rotate3d(1, 0, 0, 10deg)
            }

            80% {
                -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
                transform: perspective(400px) rotate3d(1, 0, 0, -5deg)
            }
        }

        @-webkit-keyframes ha_flipInY {
            0% {
                opacity: 0;
                -webkit-transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
                transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
                -webkit-animation-timing-function: ease-in;
                animation-timing-function: ease-in
            }

            40% {
                -webkit-transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
                transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
                -webkit-animation-timing-function: ease-in;
                animation-timing-function: ease-in
            }

            60% {
                opacity: 1;
                -webkit-transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
                transform: perspective(400px) rotate3d(0, 1, 0, 10deg)
            }

            80% {
                -webkit-transform: perspective(400px) rotate3d(0, 1, 0, -5deg);
                transform: perspective(400px) rotate3d(0, 1, 0, -5deg)
            }
        }

        @keyframes ha_flipInY {
            0% {
                opacity: 0;
                -webkit-transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
                transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
                -webkit-animation-timing-function: ease-in;
                animation-timing-function: ease-in
            }

            40% {
                -webkit-transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
                transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
                -webkit-animation-timing-function: ease-in;
                animation-timing-function: ease-in
            }

            60% {
                opacity: 1;
                -webkit-transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
                transform: perspective(400px) rotate3d(0, 1, 0, 10deg)
            }

            80% {
                -webkit-transform: perspective(400px) rotate3d(0, 1, 0, -5deg);
                transform: perspective(400px) rotate3d(0, 1, 0, -5deg)
            }
        }

        @-webkit-keyframes ha_swing {
            20% {
                -webkit-transform: rotate3d(0, 0, 1, 15deg);
                transform: rotate3d(0, 0, 1, 15deg)
            }

            40% {
                -webkit-transform: rotate3d(0, 0, 1, -10deg);
                transform: rotate3d(0, 0, 1, -10deg)
            }

            60% {
                -webkit-transform: rotate3d(0, 0, 1, 5deg);
                transform: rotate3d(0, 0, 1, 5deg)
            }

            80% {
                -webkit-transform: rotate3d(0, 0, 1, -5deg);
                transform: rotate3d(0, 0, 1, -5deg)
            }
        }

        @keyframes ha_swing {
            20% {
                -webkit-transform: rotate3d(0, 0, 1, 15deg);
                transform: rotate3d(0, 0, 1, 15deg)
            }

            40% {
                -webkit-transform: rotate3d(0, 0, 1, -10deg);
                transform: rotate3d(0, 0, 1, -10deg)
            }

            60% {
                -webkit-transform: rotate3d(0, 0, 1, 5deg);
                transform: rotate3d(0, 0, 1, 5deg)
            }

            80% {
                -webkit-transform: rotate3d(0, 0, 1, -5deg);
                transform: rotate3d(0, 0, 1, -5deg)
            }
        }

        @-webkit-keyframes ha_slideInDown {
            0% {
                visibility: visible;
                -webkit-transform: translate3d(0, -100%, 0);
                transform: translate3d(0, -100%, 0)
            }
        }

        @keyframes ha_slideInDown {
            0% {
                visibility: visible;
                -webkit-transform: translate3d(0, -100%, 0);
                transform: translate3d(0, -100%, 0)
            }
        }

        @-webkit-keyframes ha_slideInUp {
            0% {
                visibility: visible;
                -webkit-transform: translate3d(0, 100%, 0);
                transform: translate3d(0, 100%, 0)
            }
        }

        @keyframes ha_slideInUp {
            0% {
                visibility: visible;
                -webkit-transform: translate3d(0, 100%, 0);
                transform: translate3d(0, 100%, 0)
            }
        }

        @-webkit-keyframes ha_slideInLeft {
            0% {
                visibility: visible;
                -webkit-transform: translate3d(-100%, 0, 0);
                transform: translate3d(-100%, 0, 0)
            }
        }

        @keyframes ha_slideInLeft {
            0% {
                visibility: visible;
                -webkit-transform: translate3d(-100%, 0, 0);
                transform: translate3d(-100%, 0, 0)
            }
        }

        @-webkit-keyframes ha_slideInRight {
            0% {
                visibility: visible;
                -webkit-transform: translate3d(100%, 0, 0);
                transform: translate3d(100%, 0, 0)
            }
        }

        @keyframes ha_slideInRight {
            0% {
                visibility: visible;
                -webkit-transform: translate3d(100%, 0, 0);
                transform: translate3d(100%, 0, 0)
            }
        }

        .ha_fadeIn {
            -webkit-animation-name: ha_fadeIn;
            animation-name: ha_fadeIn
        }

        .ha_zoomIn {
            -webkit-animation-name: ha_zoomIn;
            animation-name: ha_zoomIn
        }

        .ha_rollIn {
            -webkit-animation-name: ha_rollIn;
            animation-name: ha_rollIn
        }

        .ha_bounce {
            -webkit-transform-origin: center bottom;
            -ms-transform-origin: center bottom;
            transform-origin: center bottom;
            -webkit-animation-name: ha_bounce;
            animation-name: ha_bounce
        }

        .ha_bounceIn {
            -webkit-animation-name: ha_bounceIn;
            animation-name: ha_bounceIn;
            -webkit-animation-duration: .75s;
            -webkit-animation-duration: calc(var(--animate-duration)*.75);
            animation-duration: .75s;
            animation-duration: calc(var(--animate-duration)*.75)
        }

        .ha_flipInX,
        .ha_flipInY {
            -webkit-animation-name: ha_flipInX;
            animation-name: ha_flipInX;
            -webkit-backface-visibility: visible !important;
            backface-visibility: visible !important
        }

        .ha_flipInY {
            -webkit-animation-name: ha_flipInY;
            animation-name: ha_flipInY
        }

        .ha_swing {
            -webkit-transform-origin: top center;
            -ms-transform-origin: top center;
            transform-origin: top center;
            -webkit-animation-name: ha_swing;
            animation-name: ha_swing
        }

        .ha_slideInDown {
            -webkit-animation-name: ha_slideInDown;
            animation-name: ha_slideInDown
        }

        .ha_slideInUp {
            -webkit-animation-name: ha_slideInUp;
            animation-name: ha_slideInUp
        }

        .ha_slideInLeft {
            -webkit-animation-name: ha_slideInLeft;
            animation-name: ha_slideInLeft
        }

        .ha_slideInRight {
            -webkit-animation-name: ha_slideInRight;
            animation-name: ha_slideInRight
        }

        .ha-css-transform-yes {
            -webkit-transition-duration: var(--ha-tfx-transition-duration, .2s);
            transition-duration: var(--ha-tfx-transition-duration, .2s);
            -webkit-transition-property: -webkit-transform;
            transition-property: transform;
            transition-property: transform, -webkit-transform;
            -webkit-transform: translate(var(--ha-tfx-translate-x, 0), var(--ha-tfx-translate-y, 0)) scale(var(--ha-tfx-scale-x, 1), var(--ha-tfx-scale-y, 1)) skew(var(--ha-tfx-skew-x, 0), var(--ha-tfx-skew-y, 0)) rotateX(var(--ha-tfx-rotate-x, 0)) rotateY(var(--ha-tfx-rotate-y, 0)) rotateZ(var(--ha-tfx-rotate-z, 0));
            transform: translate(var(--ha-tfx-translate-x, 0), var(--ha-tfx-translate-y, 0)) scale(var(--ha-tfx-scale-x, 1), var(--ha-tfx-scale-y, 1)) skew(var(--ha-tfx-skew-x, 0), var(--ha-tfx-skew-y, 0)) rotateX(var(--ha-tfx-rotate-x, 0)) rotateY(var(--ha-tfx-rotate-y, 0)) rotateZ(var(--ha-tfx-rotate-z, 0))
        }

        .ha-css-transform-yes:hover {
            -webkit-transform: translate(var(--ha-tfx-translate-x-hover, var(--ha-tfx-translate-x, 0)), var(--ha-tfx-translate-y-hover, var(--ha-tfx-translate-y, 0))) scale(var(--ha-tfx-scale-x-hover, var(--ha-tfx-scale-x, 1)), var(--ha-tfx-scale-y-hover, var(--ha-tfx-scale-y, 1))) skew(var(--ha-tfx-skew-x-hover, var(--ha-tfx-skew-x, 0)), var(--ha-tfx-skew-y-hover, var(--ha-tfx-skew-y, 0))) rotateX(var(--ha-tfx-rotate-x-hover, var(--ha-tfx-rotate-x, 0))) rotateY(var(--ha-tfx-rotate-y-hover, var(--ha-tfx-rotate-y, 0))) rotateZ(var(--ha-tfx-rotate-z-hover, var(--ha-tfx-rotate-z, 0)));
            transform: translate(var(--ha-tfx-translate-x-hover, var(--ha-tfx-translate-x, 0)), var(--ha-tfx-translate-y-hover, var(--ha-tfx-translate-y, 0))) scale(var(--ha-tfx-scale-x-hover, var(--ha-tfx-scale-x, 1)), var(--ha-tfx-scale-y-hover, var(--ha-tfx-scale-y, 1))) skew(var(--ha-tfx-skew-x-hover, var(--ha-tfx-skew-x, 0)), var(--ha-tfx-skew-y-hover, var(--ha-tfx-skew-y, 0))) rotateX(var(--ha-tfx-rotate-x-hover, var(--ha-tfx-rotate-x, 0))) rotateY(var(--ha-tfx-rotate-y-hover, var(--ha-tfx-rotate-y, 0))) rotateZ(var(--ha-tfx-rotate-z-hover, var(--ha-tfx-rotate-z, 0)))
        }

        .happy-addon>.elementor-widget-container {
            word-wrap: break-word;
            overflow-wrap: break-word
        }

        .happy-addon>.elementor-widget-container,
        .happy-addon>.elementor-widget-container * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .happy-addon p:empty {
            display: none
        }

        .happy-addon .elementor-inline-editing {
            min-height: auto !important
        }

        .happy-addon-pro img {
            max-width: 100%;
            height: auto;
            -o-object-fit: cover;
            object-fit: cover
        }

        .ha-screen-reader-text {
            position: absolute;
            overflow: hidden;
            clip: rect(1px, 1px, 1px, 1px);
            margin: -1px;
            padding: 0;
            width: 1px;
            height: 1px;
            border: 0;
            word-wrap: normal !important;
            -webkit-clip-path: inset(50%);
            clip-path: inset(50%)
        }

        .ha-has-bg-overlay>.elementor-widget-container {
            position: relative;
            z-index: 1
        }

        .ha-has-bg-overlay>.elementor-widget-container:before {
            position: absolute;
            top: 0;
            left: 0;
            z-index: -1;
            width: 100%;
            height: 100%;
            content: ""
        }

        .ha-popup--is-enabled .ha-js-popup,
        .ha-popup--is-enabled .ha-js-popup img {
            cursor: -webkit-zoom-in !important;
            cursor: zoom-in !important
        }

        .mfp-wrap .mfp-arrow,
        .mfp-wrap .mfp-close {
            background-color: transparent
        }

        .mfp-wrap .mfp-arrow:focus,
        .mfp-wrap .mfp-close:focus {
            outline-width: thin
        }

        .ha-advanced-tooltip-enable {
            position: relative;
            cursor: pointer;
            --ha-tooltip-arrow-color: black;
            --ha-tooltip-arrow-distance: 0
        }

        .ha-advanced-tooltip-enable .ha-advanced-tooltip-content {
            position: absolute;
            z-index: 999;
            display: none;
            padding: 5px 0;
            width: 120px;
            height: auto;
            border-radius: 6px;
            background-color: #000;
            color: #fff;
            text-align: center;
            opacity: 0
        }

        .ha-advanced-tooltip-enable .ha-advanced-tooltip-content::after {
            position: absolute;
            border-width: 5px;
            border-style: solid;
            content: ""
        }

        .ha-advanced-tooltip-enable .ha-advanced-tooltip-content.no-arrow::after {
            visibility: hidden
        }

        .ha-advanced-tooltip-enable .ha-advanced-tooltip-content.show {
            display: inline-block;
            opacity: 1
        }

        .ha-advanced-tooltip-enable.ha-advanced-tooltip-top .ha-advanced-tooltip-content,
        body[data-elementor-device-mode=tablet] .ha-advanced-tooltip-enable.ha-advanced-tooltip-tablet-top .ha-advanced-tooltip-content {
            top: unset;
            right: 0;
            bottom: calc(101% + var(--ha-tooltip-arrow-distance));
            left: 0;
            margin: 0 auto
        }

        .ha-advanced-tooltip-enable.ha-advanced-tooltip-top .ha-advanced-tooltip-content::after,
        body[data-elementor-device-mode=tablet] .ha-advanced-tooltip-enable.ha-advanced-tooltip-tablet-top .ha-advanced-tooltip-content::after {
            top: 100%;
            right: unset;
            bottom: unset;
            left: 50%;
            border-color: var(--ha-tooltip-arrow-color) transparent transparent transparent;
            -webkit-transform: translateX(-50%);
            -ms-transform: translateX(-50%);
            transform: translateX(-50%)
        }

        .ha-advanced-tooltip-enable.ha-advanced-tooltip-bottom .ha-advanced-tooltip-content,
        body[data-elementor-device-mode=tablet] .ha-advanced-tooltip-enable.ha-advanced-tooltip-tablet-bottom .ha-advanced-tooltip-content {
            top: calc(101% + var(--ha-tooltip-arrow-distance));
            right: 0;
            bottom: unset;
            left: 0;
            margin: 0 auto
        }

        .ha-advanced-tooltip-enable.ha-advanced-tooltip-bottom .ha-advanced-tooltip-content::after,
        body[data-elementor-device-mode=tablet] .ha-advanced-tooltip-enable.ha-advanced-tooltip-tablet-bottom .ha-advanced-tooltip-content::after {
            top: unset;
            right: unset;
            bottom: 100%;
            left: 50%;
            border-color: transparent transparent var(--ha-tooltip-arrow-color) transparent;
            -webkit-transform: translateX(-50%);
            -ms-transform: translateX(-50%);
            transform: translateX(-50%)
        }

        .ha-advanced-tooltip-enable.ha-advanced-tooltip-left .ha-advanced-tooltip-content,
        body[data-elementor-device-mode=tablet] .ha-advanced-tooltip-enable.ha-advanced-tooltip-tablet-left .ha-advanced-tooltip-content {
            top: 50%;
            right: calc(101% + var(--ha-tooltip-arrow-distance));
            bottom: unset;
            left: unset;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%)
        }

        .ha-advanced-tooltip-enable.ha-advanced-tooltip-left .ha-advanced-tooltip-content::after,
        body[data-elementor-device-mode=tablet] .ha-advanced-tooltip-enable.ha-advanced-tooltip-tablet-left .ha-advanced-tooltip-content::after {
            top: 50%;
            right: unset;
            bottom: unset;
            left: 100%;
            border-color: transparent transparent transparent var(--ha-tooltip-arrow-color);
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%)
        }

        .ha-advanced-tooltip-enable.ha-advanced-tooltip-right .ha-advanced-tooltip-content,
        body[data-elementor-device-mode=tablet] .ha-advanced-tooltip-enable.ha-advanced-tooltip-tablet-right .ha-advanced-tooltip-content {
            top: 50%;
            right: unset;
            bottom: unset;
            left: calc(101% + var(--ha-tooltip-arrow-distance));
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%)
        }

        .ha-advanced-tooltip-enable.ha-advanced-tooltip-right .ha-advanced-tooltip-content::after,
        body[data-elementor-device-mode=tablet] .ha-advanced-tooltip-enable.ha-advanced-tooltip-tablet-right .ha-advanced-tooltip-content::after {
            top: 50%;
            right: 100%;
            bottom: unset;
            left: unset;
            border-color: transparent var(--ha-tooltip-arrow-color) transparent transparent;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%)
        }

        body[data-elementor-device-mode=mobile] .ha-advanced-tooltip-enable.ha-advanced-tooltip-mobile-top .ha-advanced-tooltip-content {
            top: unset;
            right: 0;
            bottom: calc(101% + var(--ha-tooltip-arrow-distance));
            left: 0;
            margin: 0 auto
        }

        body[data-elementor-device-mode=mobile] .ha-advanced-tooltip-enable.ha-advanced-tooltip-mobile-top .ha-advanced-tooltip-content::after {
            top: 100%;
            right: unset;
            bottom: unset;
            left: 50%;
            border-color: var(--ha-tooltip-arrow-color) transparent transparent transparent;
            -webkit-transform: translateX(-50%);
            -ms-transform: translateX(-50%);
            transform: translateX(-50%)
        }

        body[data-elementor-device-mode=mobile] .ha-advanced-tooltip-enable.ha-advanced-tooltip-mobile-bottom .ha-advanced-tooltip-content {
            top: calc(101% + var(--ha-tooltip-arrow-distance));
            right: 0;
            bottom: unset;
            left: 0;
            margin: 0 auto
        }

        body[data-elementor-device-mode=mobile] .ha-advanced-tooltip-enable.ha-advanced-tooltip-mobile-bottom .ha-advanced-tooltip-content::after {
            top: unset;
            right: unset;
            bottom: 100%;
            left: 50%;
            border-color: transparent transparent var(--ha-tooltip-arrow-color) transparent;
            -webkit-transform: translateX(-50%);
            -ms-transform: translateX(-50%);
            transform: translateX(-50%)
        }

        body[data-elementor-device-mode=mobile] .ha-advanced-tooltip-enable.ha-advanced-tooltip-mobile-left .ha-advanced-tooltip-content {
            top: 50%;
            right: calc(101% + var(--ha-tooltip-arrow-distance));
            bottom: unset;
            left: unset;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%)
        }

        body[data-elementor-device-mode=mobile] .ha-advanced-tooltip-enable.ha-advanced-tooltip-mobile-left .ha-advanced-tooltip-content::after {
            top: 50%;
            right: unset;
            bottom: unset;
            left: 100%;
            border-color: transparent transparent transparent var(--ha-tooltip-arrow-color);
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%)
        }

        body[data-elementor-device-mode=mobile] .ha-advanced-tooltip-enable.ha-advanced-tooltip-mobile-right .ha-advanced-tooltip-content {
            top: 50%;
            right: unset;
            bottom: unset;
            left: calc(101% + var(--ha-tooltip-arrow-distance));
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%)
        }

        body[data-elementor-device-mode=mobile] .ha-advanced-tooltip-enable.ha-advanced-tooltip-mobile-right .ha-advanced-tooltip-content::after {
            top: 50%;
            right: 100%;
            bottom: unset;
            left: unset;
            border-color: transparent var(--ha-tooltip-arrow-color) transparent transparent;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%)
        }

        body.elementor-editor-active .happy-addon.ha-gravityforms .gform_wrapper {
            display: block !important
        }

        .ha-scroll-to-top-wrap.ha-scroll-to-top-hide {
            display: none
        }

        .ha-scroll-to-top-wrap.edit-mode,
        .ha-scroll-to-top-wrap.single-page-off {
            display: none !important
        }

        .ha-scroll-to-top-button {
            position: fixed;
            right: 15px;
            bottom: 15px;
            z-index: 9999;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            align-items: center;
            -ms-flex-align: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            -webkit-justify-content: center;
            justify-content: center;
            width: 50px;
            height: 50px;
            border-radius: 50px;
            background-color: #5636d1;
            color: #fff;
            text-align: center;
            opacity: 1;
            cursor: pointer;
            -webkit-transition: all .3s;
            transition: all .3s
        }

        .ha-scroll-to-top-button i {
            color: #fff;
            font-size: 16px
        }

        .ha-scroll-to-top-button:hover {
            background-color: #e2498a
        }
    </style>
    <link rel='stylesheet' id='eael-general-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/css/view/general.min9ddd.css?ver=5.8.11'
        media='all' />
    <link rel='stylesheet' id='eael-10-css'
        href='<?php echo theme_path(); ?>wp-content/uploads/essential-addons-elementor/eael-1023c7.css?ver=1698234132' media='all' />
    <link rel='stylesheet' id='elementor-icons-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min192d.css?ver=5.23.0' media='all' />
    <style id='elementor-icons-inline-css'>
        .elementor-add-new-section .elementor-add-templately-promo-button {
            background-color: #5d4fff;
            background-image: url(wp-content/plugins/essential-addons-for-elementor-lite/assets/admin/images/templately/logo-icon.svg);
            background-repeat: no-repeat;
            background-position: center center;
            position: relative;
        }

        .elementor-add-new-section .elementor-add-templately-promo-button>i {
            height: 12px;
        }

        body .elementor-add-new-section .elementor-add-section-area-button {
            margin-left: 0;
        }

        .elementor-add-new-section .elementor-add-templately-promo-button {
            background-color: #5d4fff;
            background-image: url(wp-content/plugins/essential-addons-for-elementor-lite/assets/admin/images/templately/logo-icon.svg);
            background-repeat: no-repeat;
            background-position: center center;
            position: relative;
        }

        .elementor-add-new-section .elementor-add-templately-promo-button>i {
            height: 12px;
        }

        body .elementor-add-new-section .elementor-add-section-area-button {
            margin-left: 0;
        }

        .elementor-add-new-section .elementor-add-templately-promo-button {
            background-color: #5d4fff;
            background-image: url(wp-content/plugins/essential-addons-for-elementor-lite/assets/admin/images/templately/logo-icon.svg);
            background-repeat: no-repeat;
            background-position: center center;
            position: relative;
        }

        .elementor-add-new-section .elementor-add-templately-promo-button>i {
            height: 12px;
        }

        body .elementor-add-new-section .elementor-add-section-area-button {
            margin-left: 0;
        }
    </style>
    <link rel='stylesheet' id='swiper-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/lib/swiper/css/swiper.min48f5.css?ver=5.3.6' media='all' />
    <link rel='stylesheet' id='elementor-post-5-css'
        href='<?php echo theme_path(); ?>wp-content/uploads/elementor/css/post-5f1c6.css?ver=1702350406' media='all' />
    <link rel='stylesheet' id='font-awesome-5-all-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/lib/font-awesome/css/all.minf92b.css?ver=3.16.6' media='all' />
    <link rel='stylesheet' id='font-awesome-4-shim-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.minf92b.css?ver=3.16.6' media='all' />
    <link rel='stylesheet' id='wpdt-elementor-widget-font-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/wpdatatables/integrations/page_builders/elementor/css/style1f07.css?ver=2.1.73'
        media='all' />
    <link rel='stylesheet' id='elementor-global-css'
        href='<?php echo theme_path(); ?>wp-content/uploads/elementor/css/global2ecb.css?ver=1702350928' media='all' />
    <link rel='stylesheet' id='elementor-post-10-css'
        href='<?php echo theme_path(); ?>wp-content/uploads/elementor/css/post-102ecb.css?ver=1702350928' media='all' />
    <link rel='stylesheet' id='hfe-widgets-style-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/header-footer-elementor/inc/widgets-css/frontend10ef.css?ver=1.6.17' media='all' />
    <link rel='stylesheet' id='elementor-post-8-css'
        href='<?php echo theme_path(); ?>wp-content/uploads/elementor/css/post-8f1c6.css?ver=1702350406' media='all' />
    <link rel='stylesheet' id='happy-icons-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/happy-elementor-addons/assets/fonts/style.min6f61.css?ver=3.8.9' media='all' />
    <link rel='stylesheet' id='font-awesome-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min1849.css?ver=4.7.0'
        media='all' />
    <link rel='stylesheet' id='elementor-post-77-css'
        href='<?php echo theme_path(); ?>wp-content/uploads/elementor/css/post-77f1c6.css?ver=1702350406' media='all' />
    <link rel='stylesheet' id='hello-elementor-css' href='<?php echo theme_path(); ?>wp-content/themes/hello-elementor/style.minc141.css?ver=2.6.1'
        media='all' />
    <link rel='stylesheet' id='happy-elementor-addons-10-css'
        href='<?php echo theme_path(); ?>wp-content/uploads/happyaddons/css/ha-107416.css?ver=3.8.9.1698234132' media='all' />
    <link rel='stylesheet' id='call-now-button-modern-style-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/call-now-button/resources/style/modern330a.css?ver=1.4.1' media='all' />
    <link rel='stylesheet' id='google-fonts-1-css'
        href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CAlata%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=auto&amp;ver=6.5'
        media='all' />
    <link rel='stylesheet' id='elementor-icons-shared-0-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3'
        media='all' />
    <link rel='stylesheet' id='elementor-icons-fa-solid-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min52d5.css?ver=5.15.3' media='all' />
    <link rel='stylesheet' id='elementor-icons-fa-regular-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3' media='all' />
    <link rel='stylesheet' id='elementor-icons-fa-brands-css'
        href='<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min52d5.css?ver=5.15.3' media='all' />
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <script src="<?php echo theme_path(); ?>wp-includes/js/jquery/jquery.minf43b.js?ver=3.7.1" id="jquery-core-js"></script>
    <script src="<?php echo theme_path(); ?>wp-includes/js/jquery/jquery-migrate.min5589.js?ver=3.4.1" id="jquery-migrate-js"></script>
    <script src="<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.minf92b.js?ver=3.16.6"
        id="font-awesome-4-shim-js"></script>
    <link rel="https://api.w.org/" href="wp-json/index.html" />
    <link rel="alternate" type="application/json" href="wp-json/wp/v2/pages/10.json" />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.php?rsd" />
    <meta name="generator" content="WordPress 6.5" />
    <link rel="canonical" href="index.html" />
    <link rel='shortlink' href='index.html' />
    <link rel="alternate" type="application/json+oembed"
        href="wp-json/oembed/1.0/embed538b.json?url=https%3A%2F%2Ftaekwondounion.com%2F" />
    <link rel="alternate" type="text/xml+oembed"
        href="wp-json/oembed/1.0/embedcb65?url=https%3A%2F%2Ftaekwondounion.com%2F&amp;format=xml" />
    <!-- HappyForms global container -->
    <script type="text/javascript">HappyForms = {};</script>
    <!-- End of HappyForms global container -->
    <meta name="generator"
        content="Elementor 3.16.6; features: e_dom_optimization, e_optimized_assets_loading, e_optimized_css_loading, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-auto">
    <link rel="icon" href="wp-content/uploads/2022/04/logogofavv-150x150.png" sizes="32x32" />
    <link rel="icon" href="wp-content/uploads/2022/04/logogofavv.png" sizes="192x192" />
    <link rel="apple-touch-icon" href="wp-content/uploads/2022/04/logogofavv.png" />
    <meta name="msapplication-TileImage"
        content="https://taekwondounion.com/wp-content/uploads/2022/04/logogofavv.png" />
    <?php
    $html = ob_get_contents();
    ob_end_clean();
    echo $html;
}

function registerAfterFooterContent(){
    ob_start();
   ?>
<script id="ht_ctc_app_js-js-extra">
        var ht_ctc_chat_var = { "number": "919583921122", "pre_filled": "Hi", "dis_m": "show", "dis_d": "show", "css": "display: none; cursor: pointer; z-index: 99999999;", "pos_d": "position: fixed; bottom: 15px; right: 15px;", "pos_m": "position: fixed; bottom: 15px; right: 10px;", "schedule": "no", "se": "150", "ani": "no-animations", "url_target_d": "_blank", "ga": "yes", "fb": "yes" };
    </script>
    <script src="<?php echo theme_path(); ?>wp-content/plugins/click-to-chat-for-whatsapp/new/inc/assets/js/app862f.js?ver=3.30.1"
        id="ht_ctc_app_js-js"></script>
    <script id="eael-general-js-extra">
        var localize = { "ajaxurl": "https:\/\/taekwondounion.com\/wp-admin\/admin-ajax.php", "nonce": "0e2c0e742e", "i18n": { "added": "Added ", "compare": "Compare", "loading": "Loading..." }, "eael_translate_text": { "required_text": "is a required field", "invalid_text": "Invalid", "billing_text": "Billing", "shipping_text": "Shipping", "fg_mfp_counter_text": "of" }, "page_permalink": "https:\/\/taekwondounion.com\/", "cart_redirectition": "", "cart_page_url": "", "el_breakpoints": { "mobile": { "label": "Mobile Portrait", "value": 767, "default_value": 767, "direction": "max", "is_enabled": true }, "mobile_extra": { "label": "Mobile Landscape", "value": 880, "default_value": 880, "direction": "max", "is_enabled": false }, "tablet": { "label": "Tablet Portrait", "value": 1024, "default_value": 1024, "direction": "max", "is_enabled": true }, "tablet_extra": { "label": "Tablet Landscape", "value": 1200, "default_value": 1200, "direction": "max", "is_enabled": false }, "laptop": { "label": "Laptop", "value": 1366, "default_value": 1366, "direction": "max", "is_enabled": false }, "widescreen": { "label": "Widescreen", "value": 2400, "default_value": 2400, "direction": "min", "is_enabled": false } } };
    </script>
    <script
        src="<?php echo theme_path(); ?>wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/js/view/general.min9ddd.js?ver=5.8.11"
        id="eael-general-js"></script>
    <script src="<?php echo theme_path(); ?>wp-content/uploads/essential-addons-elementor/eael-1023c7.js?ver=1698234132" id="eael-10-js"></script>
    <script id="happy-elementor-addons-js-extra">
        var HappyLocalize = { "ajax_url": "https:\/\/taekwondounion.com\/wp-admin\/admin-ajax.php", "nonce": "be8056d1d1", "pdf_js_lib": "https:\/\/taekwondounion.com\/wp-content\/plugins\/happy-elementor-addons\/assets\/vendor\/pdfjs\/lib" };
    </script>
    <script src="<?php echo theme_path(); ?>wp-content/plugins/happy-elementor-addons/assets/js/happy-addons.min6f61.js?ver=3.8.9"
        id="happy-elementor-addons-js"></script>
    <script src="<?php echo theme_path(); ?>wp-content/themes/hello-elementor/assets/js/hello-frontend.min8a54.js?ver=1.0.0"
        id="hello-theme-frontend-js"></script>
    <script src="<?php echo theme_path(); ?>wp-content/plugins/header-footer-elementor/inc/js/frontend10ef.js?ver=1.6.17"
        id="hfe-frontend-js-js"></script>
    <script src="<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/js/webpack.runtime.minf92b.js?ver=3.16.6"
        id="elementor-webpack-runtime-js"></script>
    <script src="<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/js/frontend-modules.minf92b.js?ver=3.16.6"
        id="elementor-frontend-modules-js"></script>
    <script src="<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min05da.js?ver=4.0.2"
        id="elementor-waypoints-js"></script>
    <script src="<?php echo theme_path(); ?>wp-includes/js/jquery/ui/core.min3f14.js?ver=1.13.2" id="jquery-ui-core-js"></script>
    <script id="elementor-frontend-js-before">
        var elementorFrontendConfig = {
            "environmentMode": { "edit": false, "wpPreview": false, "isScriptDebug": false }, "i18n": { "shareOnFacebook": "Share on Facebook", "shareOnTwitter": "Share on Twitter", "pinIt": "Pin it", "download": "Download", "downloadImage": "Download image", "fullscreen": "Fullscreen", "zoom": "Zoom", "share": "Share", "playVideo": "Play Video", "previous": "Previous", "next": "Next", "close": "Close", "a11yCarouselWrapperAriaLabel": "Carousel | Horizontal scrolling: Arrow Left & Right", "a11yCarouselPrevSlideMessage": "Previous slide", "a11yCarouselNextSlideMessage": "Next slide", "a11yCarouselFirstSlideMessage": "This is the first slide", "a11yCarouselLastSlideMessage": "This is the last slide", "a11yCarouselPaginationBulletMessage": "Go to slide" }, "is_rtl": false, "breakpoints": { "xs": 0, "sm": 480, "md": 768, "lg": 1025, "xl": 1440, "xxl": 1600 }, "responsive": { "breakpoints": { "mobile": { "label": "Mobile Portrait", "value": 767, "default_value": 767, "direction": "max", "is_enabled": true }, "mobile_extra": { "label": "Mobile Landscape", "value": 880, "default_value": 880, "direction": "max", "is_enabled": false }, "tablet": { "label": "Tablet Portrait", "value": 1024, "default_value": 1024, "direction": "max", "is_enabled": true }, "tablet_extra": { "label": "Tablet Landscape", "value": 1200, "default_value": 1200, "direction": "max", "is_enabled": false }, "laptop": { "label": "Laptop", "value": 1366, "default_value": 1366, "direction": "max", "is_enabled": false }, "widescreen": { "label": "Widescreen", "value": 2400, "default_value": 2400, "direction": "min", "is_enabled": false } } },
            "version": "3.16.6", "is_static": false, "experimentalFeatures": { "e_dom_optimization": true, "e_optimized_assets_loading": true, "e_optimized_css_loading": true, "additional_custom_breakpoints": true, "hello-theme-header-footer": true, "landing-pages": true }, "urls": { "assets": "https:\/\/taekwondounion.com\/wp-content\/plugins\/elementor\/assets\/" }, "swiperClass": "swiper-container", "settings": { "page": [], "editorPreferences": [] }, "kit": { "active_breakpoints": ["viewport_mobile", "viewport_tablet"], "global_image_lightbox": "yes", "lightbox_enable_counter": "yes", "lightbox_enable_fullscreen": "yes", "lightbox_enable_zoom": "yes", "lightbox_enable_share": "yes", "lightbox_title_src": "title", "lightbox_description_src": "description", "hello_header_logo_type": "title", "hello_header_menu_layout": "horizontal", "hello_footer_logo_type": "logo" }, "post": { "id": 10, "title": "Indian%20Taekwondo%20Union%20%E2%80%93%20ITU%20%20%E2%80%93%20Official%20Website%20%7C%20India", "excerpt": "", "featuredImage": false }
        };
    </script>
    <script src="<?php echo theme_path(); ?>wp-content/plugins/elementor/assets/js/frontend.minf92b.js?ver=3.16.6"
        id="elementor-frontend-js"></script>
   <?php
   $html = ob_get_contents();
   ob_end_clean();
   echo $html;
}

function registerBodyClass(){
    echo 'home page-template page-template-elementor_header_footer page page-id-10 ehf-header ehf-footer ehf-template-hello-elementor ehf-stylesheet-hello-elementor elementor-default elementor-template-full-width elementor-kit-5 elementor-page elementor-page-10';
}
add_shortcode('navbar', function($atts, $content){
    //  [navbar id=1871 type=vertical]
     $id = @$atts['id'];
     $type = @$atts['type'] ?? 'horizontal';
     ob_start();
     include 'navbar/nav1.php';
     $html = ob_get_contents();
	 ob_end_clean();
	 return $html;
});
