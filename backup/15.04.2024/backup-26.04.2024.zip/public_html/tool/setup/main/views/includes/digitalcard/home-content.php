<div class="page-wrapper" id="basic-info">
            <div class="separator"></div>
           <div class="upper" style="background-color:#ffffff;margin-top: 21px;">
                <!-- User Profile Pic -->
                <img  style="border: 5px solid #ffffff;margin-top:; height:auto; width:150px;" src="<?php echo theme_path(); ?>admin/ads/5368_neclogo.jpg"  class="profile-pic-img">
                <!-- User Company Name -->
                <div class="firmname" style="font-size:24px;color:#000000"><p><span style="font-size:22px"><strong>Navya Education Consultant</strong></span></p>
</div>
                <div class="firmname-underline"></div>
                <!-- User First Name and Last Name -->
                <div class="name" style="font-size:16px;color:#f20202" >
                    Parth P Bhatt  <span style="margin-top: 5px;display: block"></div>
				                     <div class="name">
				<i><b style="font-size: 14x !important;">(DIRECTOR)</b></i></span></div>
                					                 <center><div class="firmname" >
                    <a class="contact-button" href="tel:9824316611"  style="padding: 11px 11px;margin-right:15px;background-color:#00aabb">
                        <i class="fa fa-phone fa-lg"></i>
                        <!-- Call -->
                    </a>
                    <a class="contact-button" target="_blank" href="https://api.whatsapp.com/send?phone=919824316611"  style="padding: 11px 11px;margin-right:15px;background-color:#00aabb">
                        <i class="fa fa-whatsapp fa-lg"></i>
                        <!-- Whatsapp -->
                    </a>
                    <a class="contact-button" target="_blank"  href='https://maps.app.goo.gl/Pa3K3ik8dSZEyjqi8'  style="padding: 11px 11px;margin-right:15px;background-color:#00aabb">
                        <i class="fa fa-map-marker fa-lg"></i>
                        <!-- Direction -->
                    </a>
                    <a class="contact-button" target="_blank" href="mailto:parth@navyaeducation.com"  style="padding: 11px 11px;background-color:#00aabb">
                        <i class="fa fa-envelope fa-flip-horizontal fa-lg" ></i>
                        <!-- Mail -->
                    </a>
                </div></center>
            </div>
            <div class="lower">
                <div class="contact-info-container">
					
					                     <div class="contact-info-wrapper">
                        <a class="contact-piller-button" target="_blank"  href='https://maps.app.goo.gl/Pa3K3ik8dSZEyjqi8'>
                            <i class="fa fa-map-marker"></i>
                        </a>
                        <div class="contact-info">
                            <a target="_blank"  href='https://maps.app.goo.gl/Pa3K3ik8dSZEyjqi8'><p>Navya Education Consultant 405, 4th floor, Central Business Space, Opp. Fortune Landmark Hotel, Usmanpura Cross Road, Ashram Road, Ahmedabad - 380009</p>
</a>
                        </div>
                    </div>

					 					<div class="contact-info-wrapper">
                        <a class="contact-piller-button call" target="_blank" href="tel:9824316611">
                            <i class="fa fa-phone "></i>
                        </a>
                        <div class="contact-info">
                            <div style="margin-bottom: 5px;">
							<a target="_blank" href="tel:9824316611">9824316611</a> 
.							, <a target="_blank" href="tel:8490903803">8490903803</a> </div>
                            
                        </div>
                    </div>
					                     <div class="contact-info-wrapper">
                        <a class="contact-piller-button" target="_blank" href="https://navyaeducation.com/">
                            <i class="fa fa-globe"></i>
                        </a>
                        <div class="contact-info">
                            <a target="_blank" href="https://navyaeducation.com/">https://navyaeducation.com/</a>
                        </div>
                    </div>
					                     <div class="contact-info-wrapper">
                        <a class="contact-piller-button" target="_blank" href="mailto:parth@navyaeducation.com">
                            <i class="fa fa-envelope"></i>
                        </a>
                        <div class="contact-info">
                            <a target="_blank" href="mailto:parth@navyaeducation.com">parth@navyaeducation.com</a>
                        </div>
                    </div>
					                 </div>
				

<script>
function myFunction() {
	
	var txt = document.getElementById('mbl').value;
    var txt1 = document.getElementById('country_code').value;
	var url= 'https://wa.me/'+txt1+''+txt+'?text=https://mydvc.in?d=navyaeducationconsultantnec Reply with Hi incase link is not clickable    ' ;

 // document.getElementById("myAnchor").href = "http://www.cnn.com/";
   document.getElementById("swhatsapp").href = url;
  document.getElementById("demo").innerHTML = "The link above now goes to www.cnn.com.";
}
</script>
                <div style="padding: 15px;">
                    <div class="p-30"></div>
                  
                     <form class="enquiry-form" action="https://api.whatsapp.com/send" id="wtsp_form" target="_blank" >
                
                     <div class="flex">
                        <div class="enquiry-phoneNumber">
                           <select name="country_code" id="country_code"  style="padding:1px;width:100px;height:50px;" id="">
							<option data-countryCode="IN" value="91">India (+91)</option>
							<option data-countryCode="GB" value="44" >UK (+44)</option>
							<option data-countryCode="US" value="1">USA (+1)</option>
							<option data-countryCode="AE" value="971">UAE (+971)</option>
						<optgroup label="Other countries">
							<option data-countryCode="DZ" value="213">Algeria (+213)</option>
							<option data-countryCode="AD" value="376">Andorra (+376)</option>
							<option data-countryCode="AO" value="244">Angola (+244)</option><option data-countryCode="AI" value="1264">Anguilla (+1264)</option>
							<option data-countryCode="AG" value="1268">Antigua &amp; Barbuda (+1268)</option><option data-countryCode="AR" value="54">Argentina (+54)</option>
							<option data-countryCode="AM" value="374">Armenia (+374)</option><option data-countryCode="AW" value="297">Aruba (+297)</option>
							<option data-countryCode="AU" value="61">Australia (+61)</option><option data-countryCode="AT" value="43">Austria (+43)</option>
							<option data-countryCode="AZ" value="994">Azerbaijan (+994)</option><option data-countryCode="BS" value="1242">Bahamas (+1242)</option>
							<option data-countryCode="BH" value="973">Bahrain (+973)</option><option data-countryCode="BD" value="880">Bangladesh (+880)</option>
							<option data-countryCode="BB" value="1246">Barbados (+1246)</option><option data-countryCode="BY" value="375">Belarus (+375)</option>
							<option data-countryCode="BE" value="32">Belgium (+32)</option><option data-countryCode="BZ" value="501">Belize (+501)</option>
							<option data-countryCode="BJ" value="229">Benin (+229)</option><option data-countryCode="BM" value="1441">Bermuda (+1441)</option>
							<option data-countryCode="BT" value="975">Bhutan (+975)</option><option data-countryCode="BO" value="591">Bolivia (+591)</option>
							<option data-countryCode="BA" value="387">Bosnia Herzegovina (+387)</option><option data-countryCode="BW" value="267">Botswana (+267)</option>
							<option data-countryCode="BR" value="55">Brazil (+55)</option><option data-countryCode="BN" value="673">Brunei (+673)</option>
							<option data-countryCode="BG" value="359">Bulgaria (+359)</option><option data-countryCode="BF" value="226">Burkina Faso (+226)</option>
							<option data-countryCode="BI" value="257">Burundi (+257)</option><option data-countryCode="KH" value="855">Cambodia (+855)</option>
							<option data-countryCode="CM" value="237">Cameroon (+237)</option><option data-countryCode="CA" value="1">Canada (+1)</option>
							<option data-countryCode="CV" value="238">Cape Verde Islands (+238)</option><option data-countryCode="KY" value="1345">Cayman Islands (+1345)</option>
							<option data-countryCode="CF" value="236">Central African Republic (+236)</option><option data-countryCode="CL" value="56">Chile (+56)</option>
							<option data-countryCode="CN" value="86">China (+86)</option><option data-countryCode="CO" value="57">Colombia (+57)</option>
							<option data-countryCode="KM" value="269">Comoros (+269)</option><option data-countryCode="CG" value="242">Congo (+242)</option>
							<option data-countryCode="CK" value="682">Cook Islands (+682)</option><option data-countryCode="CR" value="506">Costa Rica (+506)</option>
							<option data-countryCode="HR" value="385">Croatia (+385)</option><option data-countryCode="CU" value="53">Cuba (+53)</option>
							<option data-countryCode="CY" value="90392">Cyprus North (+90392)</option><option data-countryCode="CY" value="357">Cyprus South (+357)</option>
							<option data-countryCode="CZ" value="42">Czech Republic (+42)</option><option data-countryCode="DK" value="45">Denmark (+45)</option>
							<option data-countryCode="DJ" value="253">Djibouti (+253)</option><option data-countryCode="DM" value="1809">Dominica (+1809)</option>
							<option data-countryCode="DO" value="1809">Dominican Republic (+1809)</option><option data-countryCode="EC" value="593">Ecuador (+593)</option>
							<option data-countryCode="EG" value="20">Egypt (+20)</option><option data-countryCode="SV" value="503">El Salvador (+503)</option>
							<option data-countryCode="GQ" value="240">Equatorial Guinea (+240)</option><option data-countryCode="ER" value="291">Eritrea (+291)</option>
							<option data-countryCode="EE" value="372">Estonia (+372)</option><option data-countryCode="ET" value="251">Ethiopia (+251)</option>
							<option data-countryCode="FK" value="500">Falkland Islands (+500)</option><option data-countryCode="FO" value="298">Faroe Islands (+298)</option>
							<option data-countryCode="FJ" value="679">Fiji (+679)</option><option data-countryCode="FI" value="358">Finland (+358)</option>
							<option data-countryCode="FR" value="33">France (+33)</option><option data-countryCode="GF" value="594">French Guiana (+594)</option>
							<option data-countryCode="PF" value="689">French Polynesia (+689)</option><option data-countryCode="GA" value="241">Gabon (+241)</option>
							<option data-countryCode="GM" value="220">Gambia (+220)</option><option data-countryCode="GE" value="7880">Georgia (+7880)</option>
							<option data-countryCode="DE" value="49">Germany (+49)</option><option data-countryCode="GH" value="233">Ghana (+233)</option>
							<option data-countryCode="GI" value="350">Gibraltar (+350)</option><option data-countryCode="GR" value="30">Greece (+30)</option>
							<option data-countryCode="GL" value="299">Greenland (+299)</option><option data-countryCode="GD" value="1473">Grenada (+1473)</option>
							<option data-countryCode="GP" value="590">Guadeloupe (+590)</option><option data-countryCode="GU" value="671">Guam (+671)</option>
							<option data-countryCode="GT" value="502">Guatemala (+502)</option><option data-countryCode="GN" value="224">Guinea (+224)</option>
							<option data-countryCode="GW" value="245">Guinea - Bissau (+245)</option><option data-countryCode="GY" value="592">Guyana (+592)</option>
							<option data-countryCode="HT" value="509">Haiti (+509)</option><option data-countryCode="HN" value="504">Honduras (+504)</option>
							<option data-countryCode="HK" value="852">Hong Kong (+852)</option><option data-countryCode="HU" value="36">Hungary (+36)</option>
							<option data-countryCode="IS" value="354">Iceland (+354)</option><option data-countryCode="ID" value="62">Indonesia (+62)</option>
							<option data-countryCode="IR" value="98">Iran (+98)</option><option data-countryCode="IQ" value="964">Iraq (+964)</option>
							<option data-countryCode="IE" value="353">Ireland (+353)</option><option data-countryCode="IL" value="972">Israel (+972)</option>
							<option data-countryCode="IT" value="39">Italy (+39)</option><option data-countryCode="JM" value="1876">Jamaica (+1876)</option>
							<option data-countryCode="JP" value="81">Japan (+81)</option><option data-countryCode="JO" value="962">Jordan (+962)</option>
							<option data-countryCode="KZ" value="7">Kazakhstan (+7)</option><option data-countryCode="KE" value="254">Kenya (+254)</option>
							<option data-countryCode="KI" value="686">Kiribati (+686)</option><option data-countryCode="KP" value="850">Korea North (+850)</option>
							<option data-countryCode="KR" value="82">Korea South (+82)</option><option data-countryCode="KW" value="965">Kuwait (+965)</option>
							<option data-countryCode="KG" value="996">Kyrgyzstan (+996)</option><option data-countryCode="LA" value="856">Laos (+856)</option>
							<option data-countryCode="LV" value="371">Latvia (+371)</option><option data-countryCode="LB" value="961">Lebanon (+961)</option>
							<option data-countryCode="LS" value="266">Lesotho (+266)</option><option data-countryCode="LR" value="231">Liberia (+231)</option>
							<option data-countryCode="LY" value="218">Libya (+218)</option><option data-countryCode="LI" value="417">Liechtenstein (+417)</option>
							<option data-countryCode="LT" value="370">Lithuania (+370)</option><option data-countryCode="LU" value="352">Luxembourg (+352)</option>
							<option data-countryCode="MO" value="853">Macao (+853)</option><option data-countryCode="MK" value="389">Macedonia (+389)</option>
							<option data-countryCode="MG" value="261">Madagascar (+261)</option><option data-countryCode="MW" value="265">Malawi (+265)</option>
							<option data-countryCode="MY" value="60">Malaysia (+60)</option><option data-countryCode="MV" value="960">Maldives (+960)</option>
							<option data-countryCode="ML" value="223">Mali (+223)</option><option data-countryCode="MT" value="356">Malta (+356)</option>
							<option data-countryCode="MH" value="692">Marshall Islands (+692)</option><option data-countryCode="MQ" value="596">Martinique (+596)</option>
							<option data-countryCode="MR" value="222">Mauritania (+222)</option><option data-countryCode="YT" value="269">Mayotte (+269)</option>
							<option data-countryCode="MX" value="52">Mexico (+52)</option><option data-countryCode="FM" value="691">Micronesia (+691)</option>
							<option data-countryCode="MD" value="373">Moldova (+373)</option><option data-countryCode="MC" value="377">Monaco (+377)</option>
							<option data-countryCode="MN" value="976">Mongolia (+976)</option><option data-countryCode="MS" value="1664">Montserrat (+1664)</option>
							<option data-countryCode="MA" value="212">Morocco (+212)</option><option data-countryCode="MZ" value="258">Mozambique (+258)</option>
							<option data-countryCode="MN" value="95">Myanmar (+95)</option><option data-countryCode="NA" value="264">Namibia (+264)</option>
							<option data-countryCode="NR" value="674">Nauru (+674)</option><option data-countryCode="NP" value="977">Nepal (+977)</option>
							<option data-countryCode="NL" value="31">Netherlands (+31)</option><option data-countryCode="NC" value="687">New Caledonia (+687)</option>
							<option data-countryCode="NZ" value="64">New Zealand (+64)</option><option data-countryCode="NI" value="505">Nicaragua (+505)</option>
							<option data-countryCode="NE" value="227">Niger (+227)</option><option data-countryCode="NG" value="234">Nigeria (+234)</option>
							<option data-countryCode="NU" value="683">Niue (+683)</option><option data-countryCode="NF" value="672">Norfolk Islands (+672)</option>
							<option data-countryCode="NP" value="670">Northern Marianas (+670)</option><option data-countryCode="NO" value="47">Norway (+47)</option>
							<option data-countryCode="OM" value="968">Oman (+968)</option><option data-countryCode="PK" value="92">Pakistan (+92)</option><option data-countryCode="PW" value="680">Palau (+680)</option>
							<option data-countryCode="PA" value="507">Panama (+507)</option><option data-countryCode="PG" value="675">Papua New Guinea (+675)</option>
							<option data-countryCode="PY" value="595">Paraguay (+595)</option><option data-countryCode="PE" value="51">Peru (+51)</option>
							<option data-countryCode="PH" value="63">Philippines (+63)</option><option data-countryCode="PL" value="48">Poland (+48)</option>
							<option data-countryCode="PT" value="351">Portugal (+351)</option><option data-countryCode="PR" value="1787">Puerto Rico (+1787)</option>
							<option data-countryCode="QA" value="974">Qatar (+974)</option><option data-countryCode="RE" value="262">Reunion (+262)</option>
							<option data-countryCode="RO" value="40">Romania (+40)</option><option data-countryCode="RU" value="7">Russia (+7)</option>
							<option data-countryCode="RW" value="250">Rwanda (+250)</option><option data-countryCode="SM" value="378">San Marino (+378)</option>
							<option data-countryCode="ST" value="239">Sao Tome &amp; Principe (+239)</option><option data-countryCode="SA" value="966">Saudi Arabia (+966)</option>
							<option data-countryCode="SN" value="221">Senegal (+221)</option><option data-countryCode="CS" value="381">Serbia (+381)</option>
							<option data-countryCode="SC" value="248">Seychelles (+248)</option><option data-countryCode="SL" value="232">Sierra Leone (+232)</option>
							<option data-countryCode="SG" value="65">Singapore (+65)</option><option data-countryCode="SK" value="421">Slovak Republic (+421)</option>
							<option data-countryCode="SI" value="386">Slovenia (+386)</option><option data-countryCode="SB" value="677">Solomon Islands (+677)</option>
							<option data-countryCode="SO" value="252">Somalia (+252)</option><option data-countryCode="ZA" value="27">South Africa (+27)</option>
							<option data-countryCode="ES" value="34">Spain (+34)</option><option data-countryCode="LK" value="94">Sri Lanka (+94)</option>
							<option data-countryCode="SH" value="290">St. Helena (+290)</option><option data-countryCode="KN" value="1869">St. Kitts (+1869)</option>
							<option data-countryCode="SC" value="1758">St. Lucia (+1758)</option><option data-countryCode="SD" value="249">Sudan (+249)</option>
							<option data-countryCode="SR" value="597">Suriname (+597)</option><option data-countryCode="SZ" value="268">Swaziland (+268)</option>
							<option data-countryCode="SE" value="46">Sweden (+46)</option><option data-countryCode="CH" value="41">Switzerland (+41)</option>
							<option data-countryCode="SI" value="963">Syria (+963)</option><option data-countryCode="TW" value="886">Taiwan (+886)</option>
							<option data-countryCode="TJ" value="7">Tajikstan (+7)</option><option data-countryCode="TH" value="66">Thailand (+66)</option>
							<option data-countryCode="TG" value="228">Togo (+228)</option><option data-countryCode="TO" value="676">Tonga (+676)</option>
							<option data-countryCode="TT" value="1868">Trinidad &amp; Tobago (+1868)</option><option data-countryCode="TN" value="216">Tunisia (+216)</option>
							<option data-countryCode="TR" value="90">Turkey (+90)</option><option data-countryCode="TM" value="7">Turkmenistan (+7)</option>
							<option data-countryCode="TM" value="993">Turkmenistan (+993)</option><option data-countryCode="TC" value="1649">Turks &amp; Caicos Islands (+1649)</option>
							<option data-countryCode="TV" value="688">Tuvalu (+688)</option><option data-countryCode="UG" value="256">Uganda (+256)</option>
							<option data-countryCode="UA" value="380">Ukraine (+380)</option><option data-countryCode="UY" value="598">Uruguay (+598)</option>
							<option data-countryCode="UZ" value="7">Uzbekistan (+7)</option><option data-countryCode="VU" value="678">Vanuatu (+678)</option>
							<option data-countryCode="VA" value="379">Vatican City (+379)</option><option data-countryCode="VE" value="58">Venezuela (+58)</option>
							<option data-countryCode="VN" value="84">Vietnam (+84)</option><option data-countryCode="VG" value="84">Virgin Islands - British (+1284)</option>
							<option data-countryCode="VI" value="84">Virgin Islands - US (+1340)</option><option data-countryCode="WF" value="681">Wallis &amp; Futuna (+681)</option>
							<option data-countryCode="YE" value="969">Yemen (North)(+969)</option><option data-countryCode="YE" value="967">Yemen (South)(+967)</option>
							<option data-countryCode="ZM" value="260">Zambia (+260)</option><option data-countryCode="ZW" value="263">Zimbabwe (+263)</option>	
						</optgroup>
						</select><br/>
                        </div>
                        <div class="enquiry-email">
                            <input type="text" oninput="myFunction()" style="width:250px;height:50px;" id="mbl" name="mbl" placeholder="Enter number" maxlength="10" oninput="this.value=this.value.replace(/[^0-9]/g,'');"/><br/>
                                                    <input type="text" hidden name="phone" id="phone" placeholder="WhatsApp Number with Country code"  value="+91">
					        <input type="hidden" name="text" id="text" value="https://mydvc.in?d=navyaeducationconsultantnec Reply with Hi incase link is not clickable    ">
                        </div>
                    </div>
                     
					<a href="#" class="whatsapp-button wtsp_share_btn" onclick="subForm()" id="swhatsapp" target="_blank" style="margin-left: 0px;float:center;width:100%;height:;" name="submit1">
                        <i class="fa fa-whatsapp"></i> Share on Whatsapp
                    </a>
				</form>
					<script>
				// 	$(document).ready(function(){
				// 		$('.wtsp_share_btn').on('click',function(){
				// 			$('#wtsp_form').submit();
				// 		})
						
				// 	})
					function subForm() {
						
                        var country_code = document.getElementById('country_code').value;    	
						var mbl = document.getElementById('mbl').value;
                        var text = document.getElementById('text').value;
                    	//var encoded = text.value;
                    	//var url = encodeURIComponent(unencoded).replace(/'/g,"%27").replace(/"/g,"%22");	
                        var encoded = encodeURIComponent(text);
                        var decoded = decodeURIComponent(encoded);
                        // console.log(encoded);
                        var url= 'https://api.whatsapp.com/send?phone='+country_code+''+mbl+'&text='+encoded;
                         window.open('https://api.whatsapp.com/send?phone='+country_code+''+mbl+'&text='+encoded);
                         // document.getElementById("myAnchor").href = "http://www.cnn.com/";
                        //   document.getElementById("phone").value = '+'+txt1+txt;
                        // $('#wtsp_form').prop('action', url);
				        // $('#wtsp_form').submit();
						
					}
					</script>
								
                <div class="p-20"></div>
                    <div class="shadow-buttons">
                        <a class="shadow-button" style="border: 4px solid #f17d3a;" href="parth-p-bhatt06ac.vcf?action=export&amp;id=5368" download="">
						<i class="fa fa-download shadow-button-icon"></i>Add to Phone Book</a>
                        <a class="shadow-button" style="border: 4px solid #f17d3a;cursor:pointer;"  data-toggle="modal" data-target="#shareModal" onclick="openShareModal(this, `Digital Visiting Card`)">
						<i class="fa fa-share-alt shadow-button-icon"></i>Share</a>
				</div>
                   
                    <div class="p-30"></div>
                    <ul class="inprofile share-buttons">
                                            <li class="share-button">
                                <a target="_blank" href="https://www.facebook.com/profile.php?id=100085651724521"><i style="font-size: 17px;height: 34px;width: 35px;" class="share-button-facebook fa fa-facebook fa-2x"></i></a>
                        </li>
                                                <li class="share-button">
                                <a target="_blank" href="https://www.instagram.com/navyaeducationconsultantnec/"><i style="font-size: 17px;height: 34px;width: 35px;" class="share-button-instagram fa fa-instagram fa-2x"></i></a>
                        </li>
                                            </ul>
                    <div class="p-20"></div>
                </div>
                <div class="bottom-separator"></div>
            </div>
        </div>
        
            
        <div class="section-container" id="company-profile">
            <div class="separator"></div>
            <div class="section-content-wrapper">
                              
			   <h2 class="section-header">About Us</h2>
			                   <div class="section-header-underline"></div>
               
                                                            
                     
                <div class="about-us-text"><p><span style="font-size:20px"><strong>Student Visa, Work Visa, Visitor Visa, Education, <span style="color:#f39c12">NIOS Board, </span><span style="color:#e74c3c">NWAC Board</span>, MBBS Admission, Student Loan Assistant, Passport, Air ticket, Forex Exchange, Tours Package, Hotel Booking Worldwide, Travel Insurance&nbsp;</strong></span></p>
</div>
                                
            </div>
            <div class="bottom-separator"></div>
        </div>
		 		
        <div class="section-container" id="product_services">
                <div class="separator"></div>
                <div class="section-content-wrapper">
                                    <h2 class="section-header">Products / Services</h2>
				 
                    <div class="section-header-underline"></div>
                    <div>
                                        <div class="card">
                        <h3 class="card-title"></h3>
                      
                        <img onclick="openImageModal(this)" alt="" src="<?php echo theme_path(); ?>admin/ads/5368_WhatsApp%20Image%202024-02-27%20at%203.38.53%20PM.jpg" style="width:100%;margin-bottom: 15px;">
                        <div class="product-price" style="text-align: center;">
														
							</div><div class="product-enquiry-section">
							
														<a href="https://api.whatsapp.com/send?phone=919824316611&amp;text=Hi,%20I%20am%20interested%20in%20your%20product/service:%20." 
							target="blank" class="product-enquiry-btn">Enquiry</a>
						    						</div>
	                </div>
                                        <div class="card">
                        <h3 class="card-title"></h3>
                      
                        <img onclick="openImageModal(this)" alt="" src="<?php echo theme_path(); ?>admin/ads/5368_WhatsApp%20Image%202024-02-27%20at%203.38.54%20PM.jpg" style="width:100%;margin-bottom: 15px;">
                        <div class="product-price" style="text-align: center;">
														
							</div><div class="product-enquiry-section">
							
														<a href="https://api.whatsapp.com/send?phone=919824316611&amp;text=Hi,%20I%20am%20interested%20in%20your%20product/service:%20." 
							target="blank" class="product-enquiry-btn">Enquiry</a>
						    						</div>
	                </div>
                                        <div class="card">
                        <h3 class="card-title"></h3>
                      
                        <img onclick="openImageModal(this)" alt="" src="<?php echo theme_path(); ?>admin/ads/5368_WhatsApp%20Image%202024-02-27%20at%203.38.55%20PM%20(2).jpg" style="width:100%;margin-bottom: 15px;">
                        <div class="product-price" style="text-align: center;">
														
							</div><div class="product-enquiry-section">
							
														<a href="https://api.whatsapp.com/send?phone=919824316611&amp;text=Hi,%20I%20am%20interested%20in%20your%20product/service:%20." 
							target="blank" class="product-enquiry-btn">Enquiry</a>
						    						</div>
	                </div>
                                        <div class="card">
                        <h3 class="card-title"></h3>
                      
                        <img onclick="openImageModal(this)" alt="" src="<?php echo theme_path(); ?>admin/ads/5368_WhatsApp%20Image%202024-02-27%20at%203.39.55%20PM.jpg" style="width:100%;margin-bottom: 15px;">
                        <div class="product-price" style="text-align: center;">
														
							</div><div class="product-enquiry-section">
							
														<a href="https://api.whatsapp.com/send?phone=919824316611&amp;text=Hi,%20I%20am%20interested%20in%20your%20product/service:%20." 
							target="blank" class="product-enquiry-btn">Enquiry</a>
						    						</div>
	                </div>
                                        <div class="card">
                        <h3 class="card-title"></h3>
                      
                        <img onclick="openImageModal(this)" alt="" src="<?php echo theme_path(); ?>admin/ads/5368_WhatsApp%20Image%202024-02-27%20at%203.44.08%20PM.jpg" style="width:100%;margin-bottom: 15px;">
                        <div class="product-price" style="text-align: center;">
														
							</div><div class="product-enquiry-section">
							
														<a href="https://api.whatsapp.com/send?phone=919824316611&amp;text=Hi,%20I%20am%20interested%20in%20your%20product/service:%20." 
							target="blank" class="product-enquiry-btn">Enquiry</a>
						    						</div>
	                </div>
                                        <div class="card">
                        <h3 class="card-title"></h3>
                      
                        <img onclick="openImageModal(this)" alt="" src="<?php echo theme_path(); ?>admin/ads/5368_ne4.jpg" style="width:100%;margin-bottom: 15px;">
                        <div class="product-price" style="text-align: center;">
														
							</div><div class="product-enquiry-section">
							
														<a href="https://api.whatsapp.com/send?phone=919824316611&amp;text=Hi,%20I%20am%20interested%20in%20your%20product/service:%20." 
							target="blank" class="product-enquiry-btn">Enquiry</a>
						    						</div>
	                </div>
                                        <div class="card">
                        <h3 class="card-title"></h3>
                      
                        <img onclick="openImageModal(this)" alt="" src="<?php echo theme_path(); ?>admin/ads/5368_ne2.jpg" style="width:100%;margin-bottom: 15px;">
                        <div class="product-price" style="text-align: center;">
														
							</div><div class="product-enquiry-section">
							
														<a href="https://api.whatsapp.com/send?phone=919824316611&amp;text=Hi,%20I%20am%20interested%20in%20your%20product/service:%20." 
							target="blank" class="product-enquiry-btn">Enquiry</a>
						    						</div>
	                </div>
                                        <div class="card">
                        <h3 class="card-title"></h3>
                      
                        <img onclick="openImageModal(this)" alt="" src="<?php echo theme_path(); ?>admin/ads/5368_WhatsApp%20Image%202024-02-27%20at%203.38.55%20PM.jpg" style="width:100%;margin-bottom: 15px;">
                        <div class="product-price" style="text-align: center;">
														
							</div><div class="product-enquiry-section">
							
														<a href="https://api.whatsapp.com/send?phone=919824316611&amp;text=Hi,%20I%20am%20interested%20in%20your%20product/service:%20." 
							target="blank" class="product-enquiry-btn">Enquiry</a>
						    						</div>
	                </div>
                                        </div>
                </div>
                <div class="bottom-separator"></div>
            </div>
					
        <div class="section-container" id="review">
            <div class="separator"></div>
            <div class="section-content-wrapper">
                            <h2 class="section-header">Feedbacks</h2>
			                <div class="section-header-underline"></div>
                				<table cellspacing="0" cellpadding="0" border="0" width="">
                <tr>
				    <td>
					<div style="width:; height:300px; overflow:auto;">
					 <table cellspacing="0" cellpadding="1" border="1" width="" >
					   
										<tr>
						<td>
						
					    <div class="feedback-list">
                            <div class="feedback-wrapper">
                                <span class="feedback-name-wrapper"><span class="feedback-name"><b>Ajay Yadav </span> </span>
                                <div>
                             <span class="ratings" style='color:#ffe234;'>
                                	<i class="fa fa-star color" aria-hidden="true"></i><i class="fa fa-star color" aria-hidden="true"></i><i class="fa fa-star color" aria-hidden="true"></i><i class="fa fa-star color" aria-hidden="true"></i><i class="fa fa-star color" aria-hidden="true"></i>                               </span> </div>
                                <div>Fantabulous work nd Help full too..🙏</div>
                                <hr />
                            </div>
                        </div>
							
							</td>
					</tr>
					  
										<tr>
						<td>
						
					    <div class="feedback-list">
                            <div class="feedback-wrapper">
                                <span class="feedback-name-wrapper"><span class="feedback-name"><b>Kuldip Patel </span> </span>
                                <div>
                             <span class="ratings" style='color:#ffe234;'>
                                	<i class="fa fa-star color" aria-hidden="true"></i><i class="fa fa-star color" aria-hidden="true"></i><i class="fa fa-star color" aria-hidden="true"></i><i class="fa fa-star color" aria-hidden="true"></i><i class="fa fa-star color" aria-hidden="true"></i>                               </span> </div>
                                <div>Very helpful behaviour </div>
                                <hr />
                            </div>
                        </div>
							
							</td>
					</tr>
					  
					 
						 </table>  
						</div>
					</td>
				</tr>
			</table>
<script>
	function check() 
	{
		 var captcha1 = document.getElementById("captcha_image").value;
		var captcha2 = document.getElementById("rcaptcha").value;
		if (captcha1 != captcha2) 
		{
			document.getElementById("msg").style.display="block";
		}
		else 
		{
			document.getElementById("msg").style.display="none";
		}
	}

</script>
                    <form class="feedback-form card" novalidate method="post" >
						<div class="feedback-form-heading">Give Feedback</div>
						<select class="star-rating" id="rating" name="rating">
                            <option value="">Select a rating</option>
                            <option value="5">Excellent</option>
                            <option value="4">Very Good</option>
                            <option value="3">Average</option>
                            <option value="2">Poor</option>
                            <option value="1">Terrible</option>
                        </select>
						<input type="text" name="custname" Required id="custname" placeholder="Enter Full Name"/>
						<input type="text" name="address" Required id="address" placeholder="Enter Address"/>
						<input type="text" name="mobile" maxlength="10" oninput="this.value=this.value.replace(/[^0-9]/g,'');" Required id="mobile" placeholder="Enter MobileNo"/>
						<textarea name="rating_comments" Required id="rating_comments" placeholder="Enter your Comments"></textarea>
					
						 						<div class="col col-d-4 col-t-4 col-m-12">
							<input type="text" onselectstart="return false;" onmousedown="return false;" style="background-color:lightgray;" value="2982" class="form-control" readonly id="captcha_image" name="rcaptcha1" ><br/>
						<p id="msg" style="display: none;color: red">Do not match.</p>
						</div>
						<div class="col col-d-8 col-t-8 col-m-12">
						   
								<input type="text" class="form-control" placeholder="Enter the code from the box here:" required id="rcaptcha" name="rcaptcha" >
						</div>
					
						<!-- Message:<br/> -->
						<button type="submit" class="whatsapp-button" value="" name="submit"/>Give Feedback</button>
					</form>
                </div>
                <div class="bottom-separator"></div>
            </div>
		
			 <div class="section-container" id="inquiry">
                <div class="separator"></div>
                <div class="section-content-wrapper">
                              <h2 class="section-header">Enquiry Form</h2>
				 
                   
            <form class="feedback-form card" novalidate method="post" >
				<input type="text" name="name" id="enqname" placeholder="Enter Full Name" required/><br/>
                <input type="text" name="mobile_send" id="enqmobile_send" maxlength="10" oninput="this.value=this.value.replace(/[^0-9]/g,'');" placeholder="Enter Phone Number" required/><br/>
                <input type="text" name="email" id="enqemail" placeholder="Enter Email" required/><br/>
                <textarea name="description" id="enqdescription" placeholder="Enter Message" required></textarea><br/>
                 <input hidden id="userid" name="userid" value="5368" type="text"/>
								
				<div class="col col-d-4 col-t-4 col-m-12">
					<input type="text" onselectstart="return false;" onmousedown="return false;" style="background-color:lightgray;" value="2309" 
					        class="form-control" readonly id="icaptcha1" name="rcaptcha1" /><br/>
				    <span id="cerrenq"></span>
				</div>
				<div class="col col-d-8 col-t-8 col-m-12">
				    <input type="text" class="form-control" onkeyup="checkenqcpt();" placeholder="Enter the code from the box here:" required id="icaptcha" name="icaptcha" />
				</div>
				
				<!-- Message:<br/> -->
				 <button type="button" class="whatsapp-button inquirysubmit" style="cursor: pointer;" name="inquirysave" id="inquirysave">Send</button>
		    </form>
        </div>
        <div class="bottom-separator"></div>
    </div>
	            

			
        <!-- Footer Menu -->
        <div class="footer">
            <ul class="footer-menu">
                 
					
					<li>
                    <a class="footer-menu-link" href="#basic-info">
                        <i class="footer-menu-icon fa fa-home" style="color:#00aabb"></i>
                        <div class="footer-menu-text" > Home </div>
                    </a>
					</li>
										<li>
                        <a class="footer-menu-link" href="#company-profile">
                            <i class="footer-menu-icon fa fa-briefcase" style="color:#00aabb"></i>
                        <div class="footer-menu-text" >About us</div>
                        </a>
                    </li>
                    					<li>
                        <a class="footer-menu-link" href="#product_services">
                            <i class="footer-menu-icon fa fa-picture-o fa-lg" style="color:#00aabb"></i>
                            <div class="footer-menu-text" >Products/ Services</div>
                        </a>
                    </li>
										<li>
                        <a class="footer-menu-link" href="#review">
                            <i class="footer-menu-icon fa fa-star" style="color:#00aabb"></i>
                            <div class="footer-menu-text" >Feedback</div>
                        </a>
                    </li>
						
					<li>
                        <a class="footer-menu-link" href="#inquiry">
                            <i class="footer-menu-icon fa fa-comment" style="color:#00aabb"></i>
                            <div class="footer-menu-text" >Enquiry</div>
                        </a>
                    </li>
										
					 			
			            </ul>
        </div>
        <div id="imageModal" class="modal">
            <span class="close" id="imageModalClose">&times;</span>
            <img class="modal-content fadeIn" id="img01">
            <div id="caption"></div>
        </div>
        
        <!-- The share Modal -->
        <div id="shareModal" class="modal fade">
            <div class="share-form fadeInUpBig">
                <div class="share-form-header">
                    <h3 class="share-form-header-text">Share Profile</h3>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="share-form-buttons-container">
                    <p>Share my Digital Visiting Card in your network.</p>
                    <div class="share-buttons-heading">
                        <img src="https://mydvc.in/templates/template4/Notfound.php" class="share-buttons-arrow">
                        <div class="share-buttons-heading-text">Share my Digital Visiting Card</div>
                    </div>
                    <ul class="share-buttons">
                        <li class="share-button">
                            <a target="_blank" href="https://api.whatsapp.com/send?text=https://mydvc.in?d=navyaeducationconsultantnec%0D%0AReply%20with%20Hi%20incase%20link%20is%20not%20clickable%0D%0A" >
                                <i class="share-button-whatsapp fa fa-whatsapp"></i>
                            </a>
                        </li>
                        <li class="share-button">
                            <a target="_blank" target="_blank" href="sms:?body=https://mydvc.in?d=navyaeducationconsultantnec">
                                <i class="share-button-sms fa fa-comments"></i>
                            </a>
                        </li>
                        <li class="share-button">
                            <a target="_blank" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https://mydvc.in?d=navyaeducationconsultantnec" class="fb-xfbml-parse-ignore">
                                <i class="share-button-facebook fa fa-facebook"></i>
                            </a>
                        </li>
                        <li class="share-button">
                            <a target="_blank" target="_blank" href="https://twitter.com/intent/tweet?text=https://mydvc.in?d=navyaeducationconsultantnec" data-size="large">
                                <i class="share-button-twitter fa fa-twitter"></i>
                            </a>
                        </li>
                       <li class="share-button">
							<a target="_blank" target="_blank" href="http://ca.linkedin.com/in?https://mydvc.in?d=navyaeducationconsultantnec">
                            <i class="share-button-linkedin fa fa-linkedin"></i>
							</a>
                        </li>
                        <li class="share-button">
							<a target="_blank" href="mailto:info.creativeadsbgm@gmail.com?&subject=&body=https://mydvc.in?d=navyaeducationconsultantnec">
                            <i class="share-button-mail fa fa-envelope"></i>
							</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>