
          

        <div data-elementor-type="wp-page" data-elementor-id="10" class="elementor elementor-10">
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-7f983b3 elementor-section-full_width elementor-section-stretched elementor-section-height-default elementor-section-height-default"
                data-id="7f983b3" data-element_type="section"
                data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;_ha_eqh_enable&quot;:false}">
                <div class="elementor-container elementor-column-gap-no">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-4b2e6ba"
                        data-id="4b2e6ba" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-8c29101 elementor-arrows-position-inside elementor-widget elementor-widget-image-carousel"
                                data-id="8c29101" data-element_type="widget"
                                data-settings="{&quot;slides_to_show&quot;:&quot;1&quot;,&quot;navigation&quot;:&quot;arrows&quot;,&quot;autoplay&quot;:&quot;yes&quot;,&quot;pause_on_hover&quot;:&quot;yes&quot;,&quot;pause_on_interaction&quot;:&quot;yes&quot;,&quot;autoplay_speed&quot;:5000,&quot;infinite&quot;:&quot;yes&quot;,&quot;effect&quot;:&quot;slide&quot;,&quot;speed&quot;:500}"
                                data-widget_type="image-carousel.default">
                                <div class="elementor-widget-container">
                                    <style>
                                        /*! elementor - v3.16.0 - 17-10-2023 */
                                        .elementor-widget-image-carousel .swiper,
                                        .elementor-widget-image-carousel .swiper-container {
                                            position: static
                                        }

                                        .elementor-widget-image-carousel .swiper-container .swiper-slide figure,
                                        .elementor-widget-image-carousel .swiper .swiper-slide figure {
                                            line-height: inherit
                                        }

                                        .elementor-widget-image-carousel .swiper-slide {
                                            text-align: center
                                        }

                                        .elementor-image-carousel-wrapper:not(.swiper-container-initialized):not(.swiper-initialized) .swiper-slide {
                                            max-width: calc(100% / var(--e-image-carousel-slides-to-show, 3))
                                        }
                                    </style>
                                    <div class="elementor-image-carousel-wrapper swiper-container" dir="ltr">
                                        <div class="elementor-image-carousel swiper-wrapper" aria-live="off">
                                            <div class="swiper-slide" role="group" aria-roledescription="slide"
                                                aria-label="1 of 8">
                                                <figure class="swiper-slide-inner"><img decoding="async"
                                                        class="swiper-slide-image"
                                                        src="wp-content/uploads/2023/02/Untitled-design-17.png"
                                                        alt="Untitled design (17)" /></figure>
                                            </div>
                                            <div class="swiper-slide" role="group" aria-roledescription="slide"
                                                aria-label="2 of 8">
                                                <figure class="swiper-slide-inner"><img decoding="async"
                                                        class="swiper-slide-image"
                                                        src="wp-content/uploads/2023/02/Untitled-design-18.png"
                                                        alt="Untitled design (18)" /></figure>
                                            </div>
                                            <div class="swiper-slide" role="group" aria-roledescription="slide"
                                                aria-label="3 of 8">
                                                <figure class="swiper-slide-inner"><img decoding="async"
                                                        class="swiper-slide-image"
                                                        src="wp-content/uploads/2023/02/Untitled-design-21.png"
                                                        alt="Untitled design (21)" /></figure>
                                            </div>
                                            <div class="swiper-slide" role="group" aria-roledescription="slide"
                                                aria-label="4 of 8">
                                                <figure class="swiper-slide-inner"><img decoding="async"
                                                        class="swiper-slide-image"
                                                        src="wp-content/uploads/2023/02/Untitled-design-22.png"
                                                        alt="Untitled design (22)" /></figure>
                                            </div>
                                            <div class="swiper-slide" role="group" aria-roledescription="slide"
                                                aria-label="5 of 8">
                                                <figure class="swiper-slide-inner"><img decoding="async"
                                                        class="swiper-slide-image"
                                                        src="wp-content/uploads/2023/02/Untitled-design-23.png"
                                                        alt="Untitled design (23)" /></figure>
                                            </div>
                                            <div class="swiper-slide" role="group" aria-roledescription="slide"
                                                aria-label="6 of 8">
                                                <figure class="swiper-slide-inner"><img decoding="async"
                                                        class="swiper-slide-image"
                                                        src="wp-content/uploads/2023/02/Untitled-design-24.png"
                                                        alt="Untitled design (24)" /></figure>
                                            </div>
                                            <div class="swiper-slide" role="group" aria-roledescription="slide"
                                                aria-label="7 of 8">
                                                <figure class="swiper-slide-inner"><img decoding="async"
                                                        class="swiper-slide-image"
                                                        src="wp-content/uploads/2023/02/Untitled-design-25.png"
                                                        alt="Untitled design (25)" /></figure>
                                            </div>
                                            <div class="swiper-slide" role="group" aria-roledescription="slide"
                                                aria-label="8 of 8">
                                                <figure class="swiper-slide-inner"><img decoding="async"
                                                        class="swiper-slide-image"
                                                        src="wp-content/uploads/2023/02/Untitled-design-26.png"
                                                        alt="Untitled design (26)" /></figure>
                                            </div>
                                        </div>
                                        <div class="elementor-swiper-button elementor-swiper-button-prev" role="button"
                                            tabindex="0">
                                            <i aria-hidden="true" class="eicon-chevron-left"></i>
                                        </div>
                                        <div class="elementor-swiper-button elementor-swiper-button-next" role="button"
                                            tabindex="0">
                                            <i aria-hidden="true" class="eicon-chevron-right"></i>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-ef7fa1c elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="ef7fa1c" data-element_type="section"
                data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;_ha_eqh_enable&quot;:false}">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-766c95a"
                        data-id="766c95a" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-d405f50 elementor-widget elementor-widget-eael-content-ticker"
                                data-id="d405f50" data-element_type="widget"
                                data-widget_type="eael-content-ticker.default">
                                <div class="elementor-widget-container">
                                    <div class="eael-ticker-wrap" id="eael-ticker-wrap-d405f50">
                                        <div class="ticker-badge">
                                            <span>Latest News</span>
                                        </div>
                                        <div class="swiper-container-wrap eael-ticker">
                                            <div class="swiper-container eael-content-ticker swiper-container-d405f50"
                                                data-pagination=".swiper-pagination-d405f50"
                                                data-arrow-next=".swiper-button-next-d405f50"
                                                data-arrow-prev=".swiper-button-prev-d405f50" data-effect="slide"
                                                data-speed="1000" data-autoplay="4000" data-loop="1" data-arrows="1">
                                                <div class="swiper-wrapper">
                                                    <div class="swiper-slide">
                                                        <div class="ticker-content">
                                                            <a href="2023/10/25/registration-open-for-6th-national-taekwondo-championship-2023-in-rourkela-odisha-from-29-30-december-2023/index.html"
                                                                class="ticker-content-link">Registration Open for 6TH
                                                                NATIONAL TAEKWONDO CHAMPIONSHIP 2023 in Rourkela, Odisha
                                                                from 29-30 December 2023</a>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="ticker-content">
                                                            <a href="2022/06/30/affiliation-open-for-any-federation-organisation-association-academy-club-and-get-itu-membership/index.html"
                                                                class="ticker-content-link">Affiliation Open for any
                                                                Federation/Organisation/Association/Academy/Club and get
                                                                ITU membership.</a>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="ticker-content">
                                                            <a href="2022/03/26/keep-visting-us-our-website-to-get-more-information/index.html"
                                                                class="ticker-content-link">Keep visting us our website
                                                                to get more information.</a>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="ticker-content">
                                                            <a href="2022/03/23/hello-world/index.html"
                                                                class="ticker-content-link">Dear team members you will
                                                                get all information about next tournament at our
                                                                official website</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="content-ticker-pagination">
                                                <div class="swiper-button-next swiper-button-next-d405f50"><i
                                                        class="fas fa-angle-right"></i></div>
                                                <div class="swiper-button-prev swiper-button-prev-d405f50"><i
                                                        class="fas fa-angle-left"></i></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-e3f0433 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="e3f0433" data-element_type="section" data-settings="{&quot;_ha_eqh_enable&quot;:false}">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6a6772c"
                        data-id="6a6772c" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-1ca18ce elementor-widget elementor-widget-heading"
                                data-id="1ca18ce" data-element_type="widget" data-widget_type="heading.default">
                                <div class="elementor-widget-container">
                                    <style>
                                        /*! elementor - v3.16.0 - 17-10-2023 */
                                        .elementor-heading-title {
                                            padding: 0;
                                            margin: 0;
                                            line-height: 1
                                        }

                                        .elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a {
                                            color: inherit;
                                            font-size: inherit;
                                            line-height: inherit
                                        }

                                        .elementor-widget-heading .elementor-heading-title.elementor-size-small {
                                            font-size: 15px
                                        }

                                        .elementor-widget-heading .elementor-heading-title.elementor-size-medium {
                                            font-size: 19px
                                        }

                                        .elementor-widget-heading .elementor-heading-title.elementor-size-large {
                                            font-size: 29px
                                        }

                                        .elementor-widget-heading .elementor-heading-title.elementor-size-xl {
                                            font-size: 39px
                                        }

                                        .elementor-widget-heading .elementor-heading-title.elementor-size-xxl {
                                            font-size: 59px
                                        }
                                    </style>
                                    <h2 class="elementor-heading-title elementor-size-default">Welcome to Indian
                                        Taekwondo Union</h2>
                                </div>
                            </div>
                            <section
                                class="elementor-section elementor-inner-section elementor-element elementor-element-e9a1f93 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="e9a1f93" data-element_type="section"
                                data-settings="{&quot;_ha_eqh_enable&quot;:false}">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-c9f19e7"
                                        data-id="c9f19e7" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-2ef2c6f elementor-arrows-position-inside elementor-widget elementor-widget-image-carousel"
                                                data-id="2ef2c6f" data-element_type="widget"
                                                data-settings="{&quot;slides_to_show&quot;:&quot;1&quot;,&quot;navigation&quot;:&quot;arrows&quot;,&quot;autoplay&quot;:&quot;yes&quot;,&quot;pause_on_hover&quot;:&quot;yes&quot;,&quot;pause_on_interaction&quot;:&quot;yes&quot;,&quot;autoplay_speed&quot;:5000,&quot;infinite&quot;:&quot;yes&quot;,&quot;effect&quot;:&quot;slide&quot;,&quot;speed&quot;:500}"
                                                data-widget_type="image-carousel.default">
                                                <div class="elementor-widget-container">
                                                    <div class="elementor-image-carousel-wrapper swiper-container"
                                                        dir="ltr">
                                                        <div class="elementor-image-carousel swiper-wrapper"
                                                            aria-live="off">
                                                            <div class="swiper-slide" role="group"
                                                                aria-roledescription="slide" aria-label="1 of 5">
                                                                <figure class="swiper-slide-inner"><img decoding="async"
                                                                        class="swiper-slide-image"
                                                                        src="wp-content/uploads/2023/04/ksadkasdkas.jpg"
                                                                        alt="ksadkasdkas" /></figure>
                                                            </div>
                                                            <div class="swiper-slide" role="group"
                                                                aria-roledescription="slide" aria-label="2 of 5">
                                                                <figure class="swiper-slide-inner"><img decoding="async"
                                                                        class="swiper-slide-image"
                                                                        src="wp-content/uploads/2023/02/Untitled-1200-%c3%97-700-px-1.png"
                                                                        alt="Untitled (1200 × 700 px) (1)" /></figure>
                                                            </div>
                                                            <div class="swiper-slide" role="group"
                                                                aria-roledescription="slide" aria-label="3 of 5">
                                                                <figure class="swiper-slide-inner"><img decoding="async"
                                                                        class="swiper-slide-image"
                                                                        src="wp-content/uploads/2023/02/Untitled-1200-%c3%97-700-px-2.png"
                                                                        alt="Untitled (1200 × 700 px) (2)" /></figure>
                                                            </div>
                                                            <div class="swiper-slide" role="group"
                                                                aria-roledescription="slide" aria-label="4 of 5">
                                                                <figure class="swiper-slide-inner"><img decoding="async"
                                                                        class="swiper-slide-image"
                                                                        src="wp-content/uploads/2023/02/Untitled-1200-%c3%97-700-px.png"
                                                                        alt="Untitled (1200 × 700 px)" /></figure>
                                                            </div>
                                                            <div class="swiper-slide" role="group"
                                                                aria-roledescription="slide" aria-label="5 of 5">
                                                                <figure class="swiper-slide-inner"><img decoding="async"
                                                                        class="swiper-slide-image"
                                                                        src="wp-content/uploads/2023/02/Untitled-1200-%c3%97-700-px-5.png"
                                                                        alt="Untitled (1200 × 700 px) (5)" /></figure>
                                                            </div>
                                                        </div>
                                                        <div class="elementor-swiper-button elementor-swiper-button-prev"
                                                            role="button" tabindex="0">
                                                            <i aria-hidden="true" class="eicon-chevron-left"></i>
                                                        </div>
                                                        <div class="elementor-swiper-button elementor-swiper-button-next"
                                                            role="button" tabindex="0">
                                                            <i aria-hidden="true" class="eicon-chevron-right"></i>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-71053ea"
                                        data-id="71053ea" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-f77d4b9 elementor-widget elementor-widget-text-editor"
                                                data-id="f77d4b9" data-element_type="widget"
                                                data-widget_type="text-editor.default">
                                                <div class="elementor-widget-container">
                                                    <style>
                                                        /*! elementor - v3.16.0 - 17-10-2023 */
                                                        .elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap {
                                                            background-color: #69727d;
                                                            color: #fff
                                                        }

                                                        .elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap {
                                                            color: #69727d;
                                                            border: 3px solid;
                                                            background-color: transparent
                                                        }

                                                        .elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap {
                                                            margin-top: 8px
                                                        }

                                                        .elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap-letter {
                                                            width: 1em;
                                                            height: 1em
                                                        }

                                                        .elementor-widget-text-editor .elementor-drop-cap {
                                                            float: left;
                                                            text-align: center;
                                                            line-height: 1;
                                                            font-size: 50px
                                                        }

                                                        .elementor-widget-text-editor .elementor-drop-cap-letter {
                                                            display: inline-block
                                                        }
                                                    </style>
                                                    <p style="text-align: justify;">Indian Taekwondo Union ambition is
                                                        not to run a business. It has the ambition to uplift Taekwondo
                                                        sport not only in India but at world level. The Union has the
                                                        mission to provide a platform to the players, Instructor and
                                                        Referees of national and international level among the people of
                                                        world of sports. We also want to provide name, fame and honor to
                                                        players/Instructors/Referees in sports world and public. It has
                                                        his mission to attract children of all ages and youth of India
                                                        to the games specially Taekwondo sport. So, that young
                                                        generation does not indulge in drugs and they do not indulge in
                                                        crimes. The also keep them away from drugs and crime. The Union
                                                        has the ambition that its players would be able to give extra
                                                        ordinary performances at International, World Championship and
                                                        Olympic Games.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section
                                class="elementor-section elementor-inner-section elementor-element elementor-element-5aab626 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="5aab626" data-element_type="section"
                                data-settings="{&quot;_ha_eqh_enable&quot;:false}">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-7cf31ee"
                                        data-id="7cf31ee" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-7a0010f elementor-widget elementor-widget-heading"
                                                data-id="7a0010f" data-element_type="widget"
                                                data-widget_type="heading.default">
                                                <div class="elementor-widget-container">
                                                    <h2 class="elementor-heading-title elementor-size-default"><a
                                                            href="https://www.youtube.com/@indiantaekwondounion6210">Our
                                                            Youtube Channel</a></h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section
                                class="elementor-section elementor-inner-section elementor-element elementor-element-854c9a5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="854c9a5" data-element_type="section"
                                data-settings="{&quot;_ha_eqh_enable&quot;:false}">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-e1524fc"
                                        data-id="e1524fc" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-58ba430 elementor-widget elementor-widget-video"
                                                data-id="58ba430" data-element_type="widget"
                                                data-settings="{&quot;youtube_url&quot;:&quot;https:\/\/www.youtube.com\/watch?v=TZTEcSDzRY8&quot;,&quot;video_type&quot;:&quot;youtube&quot;,&quot;controls&quot;:&quot;yes&quot;}"
                                                data-widget_type="video.default">
                                                <div class="elementor-widget-container">
                                                    <style>
                                                        /*! elementor - v3.16.0 - 17-10-2023 */
                                                        .elementor-widget-video .elementor-widget-container {
                                                            overflow: hidden;
                                                            transform: translateZ(0)
                                                        }

                                                        .elementor-widget-video .elementor-wrapper {
                                                            aspect-ratio: var(--video-aspect-ratio)
                                                        }

                                                        .elementor-widget-video .elementor-wrapper iframe,
                                                        .elementor-widget-video .elementor-wrapper video {
                                                            height: 100%;
                                                            width: 100%;
                                                            display: flex;
                                                            border: none;
                                                            background-color: #000
                                                        }

                                                        @supports not (aspect-ratio:1/1) {
                                                            .elementor-widget-video .elementor-wrapper {
                                                                position: relative;
                                                                overflow: hidden;
                                                                height: 0;
                                                                padding-bottom: calc(100% / var(--video-aspect-ratio))
                                                            }

                                                            .elementor-widget-video .elementor-wrapper iframe,
                                                            .elementor-widget-video .elementor-wrapper video {
                                                                position: absolute;
                                                                top: 0;
                                                                right: 0;
                                                                bottom: 0;
                                                                left: 0
                                                            }
                                                        }

                                                        .elementor-widget-video .elementor-open-inline .elementor-custom-embed-image-overlay {
                                                            position: absolute;
                                                            top: 0;
                                                            right: 0;
                                                            bottom: 0;
                                                            left: 0;
                                                            background-size: cover;
                                                            background-position: 50%
                                                        }

                                                        .elementor-widget-video .elementor-custom-embed-image-overlay {
                                                            cursor: pointer;
                                                            text-align: center
                                                        }

                                                        .elementor-widget-video .elementor-custom-embed-image-overlay:hover .elementor-custom-embed-play i {
                                                            opacity: 1
                                                        }

                                                        .elementor-widget-video .elementor-custom-embed-image-overlay img {
                                                            display: block;
                                                            width: 100%;
                                                            aspect-ratio: var(--video-aspect-ratio);
                                                            -o-object-fit: cover;
                                                            object-fit: cover;
                                                            -o-object-position: center center;
                                                            object-position: center center
                                                        }

                                                        @supports not (aspect-ratio:1/1) {
                                                            .elementor-widget-video .elementor-custom-embed-image-overlay {
                                                                position: relative;
                                                                overflow: hidden;
                                                                height: 0;
                                                                padding-bottom: calc(100% / var(--video-aspect-ratio))
                                                            }

                                                            .elementor-widget-video .elementor-custom-embed-image-overlay img {
                                                                position: absolute;
                                                                top: 0;
                                                                right: 0;
                                                                bottom: 0;
                                                                left: 0
                                                            }
                                                        }

                                                        .elementor-widget-video .e-hosted-video .elementor-video {
                                                            -o-object-fit: cover;
                                                            object-fit: cover
                                                        }

                                                        .e-con-inner>.elementor-widget-video,
                                                        .e-con>.elementor-widget-video {
                                                            width: var(--container-widget-width);
                                                            --flex-grow: var(--container-widget-flex-grow)
                                                        }
                                                    </style>
                                                    <div class="elementor-wrapper elementor-open-inline">
                                                        <div class="elementor-video"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-9f1de58"
                                        data-id="9f1de58" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-cf793aa elementor-widget elementor-widget-video"
                                                data-id="cf793aa" data-element_type="widget"
                                                data-settings="{&quot;youtube_url&quot;:&quot;https:\/\/www.youtube.com\/watch?v=OPrZobXQHw8&quot;,&quot;video_type&quot;:&quot;youtube&quot;,&quot;controls&quot;:&quot;yes&quot;}"
                                                data-widget_type="video.default">
                                                <div class="elementor-widget-container">
                                                    <div class="elementor-wrapper elementor-open-inline">
                                                        <div class="elementor-video"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section
                                class="elementor-section elementor-inner-section elementor-element elementor-element-d5f7eb9 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="d5f7eb9" data-element_type="section"
                                data-settings="{&quot;_ha_eqh_enable&quot;:false}">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5acff80"
                                        data-id="5acff80" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-a7f8e65 elementor-widget elementor-widget-video"
                                                data-id="a7f8e65" data-element_type="widget"
                                                data-settings="{&quot;youtube_url&quot;:&quot;https:\/\/www.youtube.com\/watch?v=372-dKoxWJ4&quot;,&quot;video_type&quot;:&quot;youtube&quot;,&quot;controls&quot;:&quot;yes&quot;}"
                                                data-widget_type="video.default">
                                                <div class="elementor-widget-container">
                                                    <div class="elementor-wrapper elementor-open-inline">
                                                        <div class="elementor-video"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-d423805"
                                        data-id="d423805" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-875e8be elementor-widget elementor-widget-video"
                                                data-id="875e8be" data-element_type="widget"
                                                data-settings="{&quot;youtube_url&quot;:&quot;https:\/\/www.youtube.com\/watch?v=Q--De_EEqcE&quot;,&quot;video_type&quot;:&quot;youtube&quot;,&quot;controls&quot;:&quot;yes&quot;}"
                                                data-widget_type="video.default">
                                                <div class="elementor-widget-container">
                                                    <div class="elementor-wrapper elementor-open-inline">
                                                        <div class="elementor-video"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </section>
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-1581de3 elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                data-id="1581de3" data-element_type="section"
                data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;_ha_eqh_enable&quot;:false}">
                <div class="elementor-background-overlay"></div>
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0f75dfe"
                        data-id="0f75dfe" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <section
                                class="elementor-section elementor-inner-section elementor-element elementor-element-728980d elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="728980d" data-element_type="section"
                                data-settings="{&quot;_ha_eqh_enable&quot;:false}">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-531d5f9"
                                        data-id="531d5f9" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-70ff7b3 elementor-widget elementor-widget-heading"
                                                data-id="70ff7b3" data-element_type="widget"
                                                data-widget_type="heading.default">
                                                <div class="elementor-widget-container">
                                                    <h2 class="elementor-heading-title elementor-size-default">Contact
                                                        us for any queries.</h2>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-3ae7c00 elementor-align-center elementor-widget elementor-widget-button"
                                                data-id="3ae7c00" data-element_type="widget"
                                                data-widget_type="button.default">
                                                <div class="elementor-widget-container">
                                                    <div class="elementor-button-wrapper">
                                                        <a class="elementor-button elementor-button-link elementor-size-sm"
                                                            href="#">
                                                            <span class="elementor-button-content-wrapper">
                                                                <span class="elementor-button-text">Contact Us</span>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </section>
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-e476d74 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="e476d74" data-element_type="section"
                data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;_ha_eqh_enable&quot;:false}">
                <div class="elementor-background-overlay"></div>
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-8bc94c7"
                        data-id="8bc94c7" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <section
                                class="elementor-section elementor-inner-section elementor-element elementor-element-d21dfbb elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="d21dfbb" data-element_type="section"
                                data-settings="{&quot;_ha_eqh_enable&quot;:false}">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-6370bc2"
                                        data-id="6370bc2" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-8cd5843 elementor-widget elementor-widget-heading"
                                                data-id="8cd5843" data-element_type="widget"
                                                data-widget_type="heading.default">
                                                <div class="elementor-widget-container">
                                                    <h2 class="elementor-heading-title elementor-size-default">Student's
                                                        Feedback</h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section
                                class="elementor-section elementor-inner-section elementor-element elementor-element-8c86577 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="8c86577" data-element_type="section"
                                data-settings="{&quot;_ha_eqh_enable&quot;:false}">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-c0bdf96"
                                        data-id="c0bdf96" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-c83c570 ha-testimonial--left ha-testimonial--basic elementor-widget elementor-widget-ha-testimonial happy-addon ha-testimonial"
                                                data-id="c83c570" data-element_type="widget"
                                                data-widget_type="ha-testimonial.default">
                                                <div class="elementor-widget-container">

                                                    <div class="ha-testimonial__content">
                                                        I Feel proud to be the member of Indian Taekwondo Union - ITU.
                                                        This Organisation has provided me Respect, Name. It has shaped
                                                        my life in a discipline manner. It gives Value to my Life.
                                                    </div>
                                                    <div class="ha-testimonial__reviewer">
                                                        <div class="ha-testimonial__reviewer-thumb">
                                                            <img decoding="async" width="435" height="600"
                                                                src="wp-content/uploads/2022/06/WhatsApp-Image-2022-05-01-at-9.40.08-PM.jpg"
                                                                class="attachment-full size-full wp-image-1300" alt=""
                                                                srcset="https://taekwondounion.com/wp-content/uploads/2022/06/WhatsApp-Image-2022-05-01-at-9.40.08-PM.jpeg 435w, https://taekwondounion.com/wp-content/uploads/2022/06/WhatsApp-Image-2022-05-01-at-9.40.08-PM-218x300.jpeg 218w"
                                                                sizes="(max-width: 435px) 100vw, 435px" />
                                                        </div>

                                                        <div class="ha-testimonial__reviewer-meta">
                                                            <div class="ha-testimonial__reviewer-name">Miss. Tanu
                                                                Agrawal</div>
                                                            <div class="ha-testimonial__reviewer-title">Uttar Pradesh
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-b4cd497"
                                        data-id="b4cd497" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-7588bc1 ha-testimonial--left ha-testimonial--basic elementor-widget elementor-widget-ha-testimonial happy-addon ha-testimonial"
                                                data-id="7588bc1" data-element_type="widget"
                                                data-widget_type="ha-testimonial.default">
                                                <div class="elementor-widget-container">

                                                    <div class="ha-testimonial__content">
                                                        It's a great honour for me to be the part of Indian Taekwondo
                                                        Union - ITU. I have been able to fulfill my dream through this
                                                        Organization. It has helped me to enhance my sportsman quality.
                                                        So grateful to Indian Taekwondo Union -ITU. </div>
                                                    <div class="ha-testimonial__reviewer">
                                                        <div class="ha-testimonial__reviewer-thumb">
                                                            <img decoding="async" width="1280" height="1280"
                                                                src="wp-content/uploads/2022/06/WhatsApp-Image-2022-05-03-at-6.18.49-AM.jpg"
                                                                class="attachment-full size-full wp-image-1305" alt=""
                                                                srcset="https://taekwondounion.com/wp-content/uploads/2022/06/WhatsApp-Image-2022-05-03-at-6.18.49-AM.jpeg 1280w, https://taekwondounion.com/wp-content/uploads/2022/06/WhatsApp-Image-2022-05-03-at-6.18.49-AM-300x300.jpeg 300w, https://taekwondounion.com/wp-content/uploads/2022/06/WhatsApp-Image-2022-05-03-at-6.18.49-AM-1024x1024.jpeg 1024w, https://taekwondounion.com/wp-content/uploads/2022/06/WhatsApp-Image-2022-05-03-at-6.18.49-AM-150x150.jpeg 150w, https://taekwondounion.com/wp-content/uploads/2022/06/WhatsApp-Image-2022-05-03-at-6.18.49-AM-768x768.jpeg 768w"
                                                                sizes="(max-width: 1280px) 100vw, 1280px" />
                                                        </div>

                                                        <div class="ha-testimonial__reviewer-meta">
                                                            <div class="ha-testimonial__reviewer-name">Miss.Vanshita
                                                                Singh</div>
                                                            <div class="ha-testimonial__reviewer-title">Delhi</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-fcfd887"
                                        data-id="fcfd887" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-34f8bb7 ha-testimonial--left ha-testimonial--basic elementor-widget elementor-widget-ha-testimonial happy-addon ha-testimonial"
                                                data-id="34f8bb7" data-element_type="widget"
                                                data-widget_type="ha-testimonial.default">
                                                <div class="elementor-widget-container">

                                                    <div class="ha-testimonial__content">
                                                        Thankyou Indian Taekwondo Union - ITU for providing me the
                                                        opportunity to show my potential and helped me to stay Fit and
                                                        Healthy. The self defence I have learned here is going to help
                                                        me a lot in near future, Infact everyone should learn it. </div>
                                                    <div class="ha-testimonial__reviewer">
                                                        <div class="ha-testimonial__reviewer-thumb">
                                                            <img loading="lazy" decoding="async" width="394"
                                                                height="455"
                                                                src="wp-content/uploads/2022/06/WhatsApp-Image-2022-05-03-at-11.29.07-AM.jpg"
                                                                class="attachment-full size-full wp-image-1304" alt=""
                                                                srcset="https://taekwondounion.com/wp-content/uploads/2022/06/WhatsApp-Image-2022-05-03-at-11.29.07-AM.jpeg 394w, https://taekwondounion.com/wp-content/uploads/2022/06/WhatsApp-Image-2022-05-03-at-11.29.07-AM-260x300.jpeg 260w"
                                                                sizes="(max-width: 394px) 100vw, 394px" />
                                                        </div>

                                                        <div class="ha-testimonial__reviewer-meta">
                                                            <div class="ha-testimonial__reviewer-name">Miss. Diksha
                                                                Dayanand Wadkar</div>
                                                            <div class="ha-testimonial__reviewer-title">Maharashtra
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </section>
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-e9a2ecc elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="e9a2ecc" data-element_type="section" data-settings="{&quot;_ha_eqh_enable&quot;:false}">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-71ec664"
                        data-id="71ec664" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-42d2c4b eael-fg-hoverer-content-align-left elementor-widget elementor-widget-eael-filterable-gallery"
                                data-id="42d2c4b" data-element_type="widget"
                                data-settings="{&quot;photo_gallery&quot;:&quot;yes&quot;,&quot;pagination&quot;:&quot;false&quot;}"
                                data-widget_type="eael-filterable-gallery.default">
                                <div class="elementor-widget-container">
                                    <style id="eael-fg-inline-css-42d2c4b">
                                        @media only screen and (max-width: 2399px) {
                                            .elementor-element.elementor-element-42d2c4b .eael-filterable-gallery-item-wrap {
                                                width: 25%;
                                            }
                                        }

                                        @media only screen and (max-width: 1024px) {
                                            .elementor-element.elementor-element-42d2c4b .eael-filterable-gallery-item-wrap {
                                                width: 50%;
                                            }
                                        }

                                        @media only screen and (max-width: 767px) {
                                            .elementor-element.elementor-element-42d2c4b .eael-filterable-gallery-item-wrap {
                                                width: 50%;
                                            }
                                        }
                                    </style>
                                    <div id="eael-filter-gallery-wrapper-42d2c4b" class="eael-filter-gallery-wrapper"
                                        data-layout-mode="hoverer" data-mfp_caption=""
                                        data-breakpoints="{&quot;mobile&quot;:{&quot;label&quot;:&quot;Mobile Portrait&quot;,&quot;value&quot;:767,&quot;default_value&quot;:767,&quot;direction&quot;:&quot;max&quot;,&quot;is_enabled&quot;:true},&quot;mobile_extra&quot;:{&quot;label&quot;:&quot;Mobile Landscape&quot;,&quot;value&quot;:880,&quot;default_value&quot;:880,&quot;direction&quot;:&quot;max&quot;,&quot;is_enabled&quot;:false},&quot;tablet&quot;:{&quot;label&quot;:&quot;Tablet Portrait&quot;,&quot;value&quot;:1024,&quot;default_value&quot;:1024,&quot;direction&quot;:&quot;max&quot;,&quot;is_enabled&quot;:true},&quot;tablet_extra&quot;:{&quot;label&quot;:&quot;Tablet Landscape&quot;,&quot;value&quot;:1200,&quot;default_value&quot;:1200,&quot;direction&quot;:&quot;max&quot;,&quot;is_enabled&quot;:false},&quot;laptop&quot;:{&quot;label&quot;:&quot;Laptop&quot;,&quot;value&quot;:1366,&quot;default_value&quot;:1366,&quot;direction&quot;:&quot;max&quot;,&quot;is_enabled&quot;:false},&quot;widescreen&quot;:{&quot;label&quot;:&quot;Widescreen&quot;,&quot;value&quot;:2400,&quot;default_value&quot;:2400,&quot;direction&quot;:&quot;min&quot;,&quot;is_enabled&quot;:false}}"
                                        data-default_control_key="0" data-custom_default_control="1">


                                        <div class="eael-filter-gallery-container eael-filter-gallery-grid"
                                            data-images-per-page="" data-total-gallery-items="16"
                                            data-nomore-item-text=""
                                            data-settings="{&quot;grid_style&quot;:&quot;grid&quot;,&quot;popup&quot;:&quot;buttons&quot;,&quot;duration&quot;:500,&quot;gallery_enabled&quot;:&quot;yes&quot;,&quot;video_gallery_yt_privacy&quot;:&quot;&quot;,&quot;control_all_text&quot;:null,&quot;post_id&quot;:10,&quot;widget_id&quot;:&quot;42d2c4b&quot;}"
                                            data-search-all=""
                                            data-gallery-items="[&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/2-1-scaled.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/2-1-scaled.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/2-1-scaled.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/3-1-scaled.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/3-1-scaled.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/3-1-scaled.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/4-1-scaled.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/4-1-scaled.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/4-1-scaled.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/6-1-scaled.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/6-1-scaled.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/6-1-scaled.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/9-1-scaled.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/9-1-scaled.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/9-1-scaled.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/10-1-scaled.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/10-1-scaled.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/10-1-scaled.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/11-1-scaled.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/11-1-scaled.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/11-1-scaled.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/13-1-scaled.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/13-1-scaled.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/13-1-scaled.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/15-1-scaled.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/15-1-scaled.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/15-1-scaled.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/16-1-scaled.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/16-1-scaled.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/16-1-scaled.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/17-1-scaled.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/17-1-scaled.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/17-1-scaled.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/18-1.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/18-1.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/18-1.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/19-1.jpeg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/19-1.jpeg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/19-1.jpeg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/23-1.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/23-1.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/23-1.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/28-1-scaled.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/28-1-scaled.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/28-1-scaled.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;,&quot;\u003Cdiv class=\u0022eael-filterable-gallery-item-wrap\u0022\u003E\n\t\t\t\t\u003Cdiv class=\u0022eael-gallery-grid-item\u0022\u003E\u003Ca href=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/41.jpg/u0022.html class=\u0022eael-magnific-link eael-magnific-link-clone media-content-wrap active\u0022 data-elementor-open-lightbox=\u0022no\u0022\u003E\u003Cdiv class=\u0022gallery-item-thumbnail-wrap\u0022\u003E\u003Cimg src=u0022https_/taekwondounion.com/wp-content/uploads/2023/03/41.jpg/u0022.html data-lazy-src=\u0022https:\/\/taekwondounion.com\/wp-content\/uploads\/2023\/03\/41.jpg\u0022 alt=\u0022\u0022 class=\u0022gallery-item-thumbnail\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-wrap caption-style-hoverer eael-slide-up\u0022\u003E\u003Cdiv class=\u0022gallery-item-hoverer-bg\u0022\u003E\u003C\/div\u003E\u003Cdiv class=\u0022gallery-item-caption-over\u0022\u003E\u003C\/div\u003E\u003C\/div\u003E\u003C\/a\u003E\u003C\/a\u003E\u003C\/div\u003E\u003C\/div\u003E&quot;]"
                                            data-init-show="16">
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/2-1-scaled.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/2-1-scaled.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/2-1-scaled.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/3-1-scaled.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/3-1-scaled.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/3-1-scaled.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/4-1-scaled.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/4-1-scaled.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/4-1-scaled.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/6-1-scaled.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/6-1-scaled.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/6-1-scaled.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/9-1-scaled.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/9-1-scaled.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/9-1-scaled.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/10-1-scaled.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/10-1-scaled.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/10-1-scaled.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/11-1-scaled.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/11-1-scaled.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/11-1-scaled.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/13-1-scaled.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/13-1-scaled.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/13-1-scaled.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/15-1-scaled.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/15-1-scaled.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/15-1-scaled.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/16-1-scaled.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/16-1-scaled.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/16-1-scaled.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/17-1-scaled.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/17-1-scaled.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/17-1-scaled.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/18-1.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/18-1.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/18-1.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/19-1.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/19-1.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/19-1.jpeg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/23-1.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/23-1.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/23-1.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/28-1-scaled.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/28-1-scaled.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/28-1-scaled.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                            <div class="eael-filterable-gallery-item-wrap">
                                                <div class="eael-gallery-grid-item"><a
                                                        href="wp-content/uploads/2023/03/41.jpg"
                                                        class="eael-magnific-link eael-magnific-link-clone media-content-wrap active"
                                                        data-elementor-open-lightbox="no">
                                                        <div class="gallery-item-thumbnail-wrap"><img decoding="async"
                                                                src="wp-content/uploads/2023/03/41.jpg"
                                                                data-lazy-src="https://taekwondounion.com/wp-content/uploads/2023/03/41.jpg"
                                                                alt="" class="gallery-item-thumbnail"></div>
                                                        <div
                                                            class="gallery-item-caption-wrap caption-style-hoverer eael-slide-up">
                                                            <div class="gallery-item-hoverer-bg"></div>
                                                            <div class="gallery-item-caption-over"></div>
                                                        </div>
                                                    </a></a></div>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

       